#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
[[ -x .venv-parrotgo-chat/bin/python ]] || python3.12 -m venv .venv-parrotgo-chat
.venv-parrotgo-chat/bin/python -m pip install --require-hashes -r scripts/parrotgo_chat/requirements.txt
.venv-parrotgo-chat/bin/python scripts/parrotgo_chat/init_env.py
port="${1:-8001}"
export ALLOWED_ORIGINS="http://127.0.0.1:$port,http://localhost:$port,http://127.0.0.1:5173,http://localhost:5173"
exec .venv-parrotgo-chat/bin/python -m uvicorn src.api.parrotgo_chat.routes:app --host 127.0.0.1 --port "$port" --workers 1
