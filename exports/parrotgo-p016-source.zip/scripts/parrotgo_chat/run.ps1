param([int]$Port = 8001)
$ErrorActionPreference = "Stop"
$chatRoot = (Resolve-Path (Join-Path $PSScriptRoot "../..")).Path
Set-Location -LiteralPath $chatRoot
$chatPython = Join-Path $chatRoot ".venv-parrotgo-chat/Scripts/python.exe"
if (-not (Test-Path -LiteralPath $chatPython)) {
    py -3.12 -m venv .venv-parrotgo-chat
    if ($LASTEXITCODE -ne 0) { throw "Python 3.12 is required" }
}
& $chatPython -m pip install --require-hashes -r scripts/parrotgo_chat/requirements.txt
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed" }
& $chatPython scripts/parrotgo_chat/init_env.py
if ($LASTEXITCODE -ne 0) { throw "Configuration initialization failed" }
$env:ALLOWED_ORIGINS = "http://127.0.0.1:$Port,http://localhost:$Port,http://127.0.0.1:5173,http://localhost:5173"
& $chatPython -m uvicorn src.api.parrotgo_chat.routes:app --host 127.0.0.1 --port $Port --workers 1
