"""Initialize only the isolated chat configuration."""
import secrets
from pathlib import Path

root = Path(__file__).resolve().parents[2]
target = root / ".env.parrotgo-chat"
if target.exists():
    print("Keeping existing .env.parrotgo-chat")
else:
    text = (root / ".env.parrotgo-chat.example").read_text(encoding="utf-8")
    text = text.replace("APP_SECRET=\n", "APP_SECRET=" + secrets.token_urlsafe(48) + "\n")
    with target.open("x", encoding="utf-8", newline="\n") as output:
        output.write(text)
    print("Created .env.parrotgo-chat (offline demo)")
