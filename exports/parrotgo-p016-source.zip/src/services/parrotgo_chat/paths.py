"""Read-only packaged fixture resources."""
from pathlib import Path

FIXTURE_DIR = Path(__file__).resolve().parent / "fixtures"
