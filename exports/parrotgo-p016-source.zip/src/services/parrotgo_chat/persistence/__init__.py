"""Persistent graph checkpoints and sandbox operation ledger.

API inbox and published views are owned by ``src.services.parrotgo_chat.api_store``. Checkpoint state
remains authoritative for conversation decisions.
"""
