"""Versioned prompt resources."""
