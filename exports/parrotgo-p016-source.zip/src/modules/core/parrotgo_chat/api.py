"""Text entrypoint for the host Core/Speech adapter."""
from src.modules.core.parrotgo_chat.text import TextBot, main, main_async

__all__ = ["TextBot", "core_func", "main", "main_async"]

async def core_func(user_text: str, session_id: str = "default", **kwargs) -> str:
    """First input requires customer_phone/customer_name; see integration guide."""
    return await main_async(user_text, session_id=session_id, **kwargs)
