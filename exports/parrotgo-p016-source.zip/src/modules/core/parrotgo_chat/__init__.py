"""Isolated P-016 chat orchestration."""
