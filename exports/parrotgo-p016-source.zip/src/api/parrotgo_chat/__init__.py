"""Isolated ParrotGo chat module."""
