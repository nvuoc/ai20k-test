Xem [hướng dẫn ghép và chạy](../../../docs/PARROTGO_CHAT_INTEGRATION.md).
