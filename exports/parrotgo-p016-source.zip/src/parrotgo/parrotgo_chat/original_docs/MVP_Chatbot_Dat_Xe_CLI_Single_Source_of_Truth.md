# MVP Chatbot Đặt Xe Tổng Đài — Text CLI

## 0. Mục đích của tài liệu

1. Chatbot đang giải quyết bài toán gì và MVP làm đến đâu.
2. Một cuốc xe cần những dữ liệu nào để được tạo.
3. Hệ thống lưu state, intent và slot như thế nào.
4. Bot phải xử lý một turn hội thoại theo thứ tự nào.
5. Pickup và destination khác nhau ra sao về mức độ chính xác.
6. Khi nào bot được hỏi thêm, khi nào phải dừng hỏi để tránh gây ức chế.
7. Khi nào phải chuyển sang `human_handoff`.
8. Kiến trúc module cần triển khai cho CLI MVP.
9. Những tình huống hội thoại thực tế phải test trước khi nghiệm thu.
10. Definition of Done và đầu ra cần bàn giao.

Tài liệu gồm hai phần lớn:

- **Phần I — Đặc tả sản phẩm và nghiệp vụ:** định nghĩa hành vi mà hệ thống bắt buộc phải có.
- **Phần II — Kế hoạch triển khai và kiểm thử:** chuyển đặc tả thành module, thuật toán, backlog, test case và tiêu chí nghiệm thu.

Nếu có mâu thuẫn giữa ví dụ hội thoại và rule nghiệp vụ, **rule nghiệp vụ và thứ tự ưu tiên trong tài liệu này là nguồn quyết định cuối cùng**.

---

## 0.1. Tóm tắt hệ thống trong 3 phút

MVP là chatbot đặt xe chạy bằng **Text CLI**. Khách nhập tên, số điện thoại và trò chuyện bằng text. Bot có nhiệm vụ thu thập đủ bốn thông tin cốt lõi:

| Slot | Bắt buộc | Mức chính xác tối thiểu |
|---|---:|---|
| `pickup` | Có | Phải đủ để tài xế tìm được khách, hoặc dùng default pickup hợp lệ của Mega POI |
| `destination` | Có | Có thể tương đối: tên đường, POI lớn, hoặc tối thiểu xã/phường + tỉnh/thành theo cơ chế fallback |
| `pickup_time` | Có | Đi ngay hoặc thời gian hẹn cụ thể |
| `vehicle_type` | Có | `xe_may`, `oto_4_cho`, `oto_7_cho` |

Các trường `passengers`, `stopovers`, `general_note` là **tùy chọn**. Bot không được chủ động hỏi từng trường này nếu khách không nêu.

Một nguyên tắc xuyên suốt của MVP là:

> **Thông tin khách đã nói hợp lệ thì không được bắt khách nói lại; thông tin không cần thiết để tạo cuốc thì không được gặng hỏi; khi bot không còn khả năng xử lý an toàn thì phải biết dừng và handoff.**

### Vòng đời tối thiểu

```text
Khởi tạo session
    ↓
Nhận user turn
    ↓
Extract multi-intent + entity
    ↓
Cập nhật state có kiểm soát
    ↓
Resolve địa chỉ / trả lời FAQ nếu cần
    ↓
Áp dụng priority + anti-frustration rules
    ↓
Đủ 4 core slots?
 ┌───────┴────────┐
Không             Có
 ↓                 ↓
Hỏi đúng          Xác nhận / tạo booking
1 thông tin        ↓
còn thiếu          booked

Bất kỳ thời điểm nào:
request_operator / API_ERROR / pickup unsafe / fallback_count >= 2
    ↓
human_handoff → operator_required
```

---

## 0.2. Thuật ngữ nhanh

| Thuật ngữ | Ý nghĩa trong tài liệu này |
|---|---|
| **Turn** | Một lượt khách gửi text và bot xử lý/trả lời |
| **Slot** | Một trường dữ liệu của booking, ví dụ pickup hoặc vehicle type |
| **Intent** | Ý định trong câu khách; một turn có thể có nhiều intent |
| **Entity** | Giá trị bóc tách từ câu khách để cập nhật slot |
| **Confirmed** | Slot đã được khách xác nhận hoặc được rule fallback cho phép tự chốt |
| **Mega POI** | Khu vực lớn có nhiều cổng/sảnh/tòa, ví dụ sân bay, Times City, Ocean Park |
| **Clarification** | Một câu hỏi làm rõ khi dữ liệu chưa đủ dùng |
| **Fallback** | Cơ chế tiếp tục xử lý khi không thể có dữ liệu chi tiết hơn nhưng nghiệp vụ cho phép dùng mức tương đối |
| **Human handoff** | Dừng bot tự động và chuyển trạng thái phiên sang cần tổng đài viên |
| **RAG/KB** | Nguồn kiến thức tĩnh để trả lời FAQ như giá/km hoặc chính sách |
| **Map API** | Adapter geocoding/POI/routing; provider cụ thể không bị khóa trong MVP |

---

# PHẦN I — ĐẶC TẢ SẢN PHẨM VÀ NGHIỆP VỤ

Phần này mô tả **hành vi bắt buộc** của MVP. Dev và QA phải coi đây là contract nghiệp vụ.

## 1. Phạm vi MVP, khởi tạo phiên & tương tác cơ bản

### 1.1. Phạm vi MVP

* MVP hiện tại chạy ở **Text CLI**. Người dùng nhập nội dung dạng text; các thành phần Voice như Caller ID, Speech-to-Text (STT), chuyển line tổng đài chỉ được xem là **adapter/giai đoạn mở rộng**, không phải phụ thuộc bắt buộc của MVP.
* Logic nghiệp vụ cốt lõi (intent, slot filling, geocoding, RAG, xác nhận, hủy cuốc) phải độc lập với kênh giao tiếp để sau này có thể tái sử dụng cho Voicebot.

### 1.2. Khởi tạo phiên (Session)

* Khách hàng nhập **Số điện thoại** và **Tên** để bắt đầu phiên MVP.
* `session_id` là một UUID riêng cho từng cuộc hội thoại/phiên đặt xe; **không dùng SĐT làm Session ID**.
* `customer_phone` là khóa nhận diện khách hàng để truy vấn CRM/lịch sử. Một số điện thoại có thể có nhiều `session_id` khác nhau theo thời gian.
* Toàn bộ message, slot và action của phiên được lưu theo `session_id`.

### 1.3. Cơ chế báo giá

* Tổng đài không tính tiền trọn gói từ trước.
* Bot chỉ báo **giá tiền trên mỗi KM** (thông tin lấy từ RAG/Knowledge Base).
* Số tiền cuối cùng phụ thuộc vào đồng hồ tính tiền/quãng đường thực tế tài xế đi.

### 1.4. Cá nhân hóa từ lịch sử

* Hệ thống dùng `customer_phone` truy vấn CRM để lấy các địa chỉ quen thuộc, ví dụ: *"Có phải đón anh ở công ty như mọi khi không?"*.
* Ở Voice phase, `customer_phone` có thể lấy từ Caller ID. Ở MVP Text CLI, số điện thoại do người dùng nhập khi khởi tạo phiên.

---

## 2. Data Model (Thực thể Cuốc Xe - Booking Entity)

Một cuốc xe hoàn chỉnh lưu vào Database gồm:

### 2.1. Thông tin định danh

* Mã ID cuốc xe (`booking_id`)
* `session_id`
* Tên khách hàng
* Số điện thoại

### 2.2. Thông tin bắt buộc (Bộ 4 thông tin cốt lõi để tạo cuốc)

* **Điểm đón (Pickup):** Bắt buộc phải xác định chính xác vị trí để tài xế tìm và đón được khách.
* **Điểm đến (Destination):** Chỉ cần xác định ở mức **tương đối** (tên đường như *đường Hồ Tùng Mậu*, địa danh lớn như *Vincom Bà Triệu*, *Aeon Mall Hà Đông*, hoặc tối thiểu xác định được **Xã/Phường + Tỉnh/Thành phố** của nơi khách muốn đến).
* **Thời gian đón (Pickup Time):** Đón ngay hoặc thời gian cụ thể hẹn trước.
* **Loại xe (Vehicle Type):** `xe_may`, `oto_4_cho`, `oto_7_cho`.

### 2.3. Thông tin bổ sung (Tùy chọn - Không chủ động gặng hỏi)

* **Điểm dừng (Stopovers):** Chỉ thu thập nếu khách chủ động yêu cầu đi nhiều điểm.
* **Số hành khách (Passengers):** Mặc định theo sức chứa xe nếu khách không nêu.
* **Ghi chú chung (Notes):** Ghi chú thêm cho tài xế (ví dụ: *"cốp rộng"*, *"tài xế không hút thuốc"*, *"đang đứng đối diện cổng trường"*).

> **Nguyên tắc chống ức chế:** Nếu khách không chủ động đưa ra yêu cầu về điểm dừng, số khách hoặc ghi chú, bot **tuyệt đối không hỏi dò** từng thông tin này. Chỉ cần đủ 4 thông tin bắt buộc tại Mục 2.2 là có thể tiến hành tạo cuốc xe.

### 2.4. Thông tin hệ thống tự tính toán

* Quãng đường ước tính (Distance)
* Tọa độ đã chuẩn hóa của pickup, destination và các stopover (với destination có thể là tọa độ trung tâm xã/phường/tuyến đường)
* Cờ Mega POI và thông tin default pickup/drop-off nếu có

### 2.5. Trạng thái của từng slot

Mỗi slot quan trọng không chỉ có `value`, mà cần có trạng thái để phân biệt dữ liệu mới bóc tách với dữ liệu đã được khách xác nhận hoặc được hệ thống tự động chốt theo cơ chế fallback.

Các trạng thái đề xuất:

* `empty`: chưa có dữ liệu
* `extracted`: đã bóc tách nhưng chưa xác nhận
* `confirmed`: khách đã xác nhận, hoặc hệ thống tự động xác nhận theo cơ chế fallback chấp nhận tương đối
* `needs_clarification`: dữ liệu chưa đủ rõ / cần hỏi lại

Điều này giúp xử lý đúng các intent `confirm`, `deny`, `change_info` mà không phải xóa dữ liệu một cách mù quáng.

---

## 3. Phân loại Ý định (Intents)

### 3.1. Nguyên tắc Multi-intent

Mỗi câu nói/lời nhập của khách hàng có thể chứa **một hoặc nhiều ý định**. Vì vậy hệ thống phải lưu danh sách `intents`, không dùng một biến `intent` đơn lẻ.

Ví dụ:

> "Đón anh ở 12 Nguyễn Trãi, đổi sang xe 7 chỗ nhé, mà giá bao nhiêu một cây?"

Có thể đồng thời chứa:

* `provide_info` → pickup = "12 Nguyễn Trãi"
* `change_info` → vehicle_type = "oto_7_cho"
* `ask_question` → hỏi giá/km

### 3.2. Nhóm Giao dịch (Transactional)

* `provide_info`: Cung cấp thông tin mới; bóc tách chính xác entity/slot.
  * Ví dụ: *"Cho xe 4 chỗ, à thôi 7 chỗ đi"* → giá trị cuối cùng của `vehicle_type` là `oto_7_cho`.

* `change_info`: Thay đổi thông tin đã có; cập nhật đè đúng slot được nhắc tới và chuyển trạng thái slot đó về `extracted` hoặc `needs_clarification` tùy dữ liệu mới.

* `confirm`: Xác nhận slot/action bot vừa hỏi.
  * Không dùng một cờ `True` chung.
  * Chỉ chuyển các slot nằm trong `last_bot_action.target_slots` sang `confirmed`.

* `deny`: Từ chối thông tin bot vừa hỏi.
  * Nếu khách chỉ rõ slot sai → chỉ invalidate/xóa slot đó.
  * Nếu bot đang xác nhận nhiều slot và khách nói rõ giá trị thay thế → cập nhật đúng slot được sửa, **không xóa các slot còn lại**.
  * Nếu bot đang xác nhận nhiều slot nhưng khách chỉ nói *"không"* mà không chỉ rõ slot nào sai → không xóa toàn bộ; hỏi ngắn gọn slot nào cần sửa.

* `cancel`: Hủy cuốc.
  * Bot hỏi xác nhận hủy.
  * Nếu khách `confirm` → kết thúc phiên đặt xe với trạng thái canceled.
  * Nếu khách `deny` → quay lại tiến trình thu thập/xác nhận thông tin còn thiếu.

* `repeat_request`: Yêu cầu nói/hiển thị lại.
  * Có thể đọc lại slot cụ thể hoặc tóm tắt toàn bộ cuốc xe.

### 3.3. Nhóm Hỏi - Đáp & Yêu cầu hỗ trợ

* `ask_question`: Câu hỏi cần trả lời bằng RAG, Tool/API hoặc Session Management (xem mục 4).
* `chit_chat`: Bot trả lời ngắn gọn, tự nhiên rồi quay lại mục tiêu hoàn thiện cuốc xe.
* `request_operator`: Khách chủ động yêu cầu nói chuyện với người thật hoặc tổng đài viên (ví dụ: *"cho tôi gặp nhân viên"*, *"nối máy cho tổng đài viên"*).

### 3.4. Nhóm Xử lý lỗi

* `unclear`: Không hiểu ý chính của khách. Tăng `fallback_count`.
  * Nếu câu vẫn chứa entity hợp lệ thì **vẫn cập nhật entity đó**.
  * Sau đó bot hỏi lại phần còn thiếu hoặc phần đang cần làm rõ.

### 3.5. Thứ tự xử lý một turn có nhiều intent

Để tránh mất dữ liệu, một turn nên được xử lý theo nguyên tắc:

1. Bóc tách toàn bộ entity/slot từ câu khách.
2. Áp dụng `change_info`/giá trị sửa cuối cùng trước khi ghi state.
3. Xử lý `confirm`/`deny` dựa trên `last_bot_action`.
4. Trả lời `ask_question` nếu có.
5. Xử lý `cancel` nếu xuất hiện và cần xác nhận hủy, hoặc kích hoạt chuyển máy nếu có `request_operator`.
6. Sau cùng mới quyết định câu hỏi tiếp theo cho slot còn thiếu/chưa rõ.

---

## 4. Luồng Hỏi - Đáp (RAG & Tools)

Phân loại câu hỏi của khách để điều hướng xử lý:

### Nhóm 1: Static FAQ → RAG / Knowledge Base

Các thông tin tương đối ổn định:

* Sức chứa hành lý
* Thú cưng
* Đồ cồng kềnh
* Ghế trẻ em
* Quy định hút thuốc
* Giá trên km
* Chính sách dịch vụ khác

### Nhóm 2: Dynamic API → Function Calling / Tools

Các thông tin phụ thuộc thời gian/không gian:

* Quãng đường ước tính
* Thời gian đi dự kiến
* Thời tiết
* Geocoding địa chỉ
* Kiểm tra một điểm có nằm trên/gần lộ trình không
* Tìm POI, ngã tư, cổng/sảnh, default pickup/drop-off

### Nhóm 3: Session Management

Các câu hỏi dựa trên state hiện tại, ví dụ:

* *"Nãy tôi đặt đi đâu nhỉ?"*
* *"Tôi đã chọn xe gì rồi?"*
* *"Đọc lại giúp tôi thông tin chuyến đi."*

### Quy tắc khi câu hỏi xuất hiện cùng dữ liệu đặt xe

Bot phải vừa trả lời câu hỏi, vừa giữ/cập nhật các slot hợp lệ trong cùng turn. Không được vì `ask_question` mà bỏ qua `provide_info` hoặc `change_info`.

---

## 5. Xử lý địa chỉ, định vị & Quy tắc chuyển máy tổng đài

### 5.1. Nguyên tắc chung

* **Điểm đón (Pickup)** phải đủ chính xác để tài xế có thể tìm khách hoặc phải có cơ chế fallback rõ ràng.
* **Điểm đến (Destination)** có thể chấp nhận mức chi tiết thấp hơn pickup (đặc biệt Mega POI, tên trục đường hoặc cấp xã/phường + tỉnh/thành phố), vì tài xế có thể trao đổi lại với khách khi di chuyển.
* **Stopover** phải được geocode thành cấu trúc địa chỉ đầy đủ như pickup/destination nếu khách có yêu cầu dừng đỗ.
* Không dùng tọa độ trung tâm của một vùng/đường quá rộng làm pickup nếu điều đó không giúp tài xế tìm được khách.

---

### Các trường hợp xử lý chi tiết:

#### Trường hợp 1: Khách cung cấp thông tin cấp vùng rộng (Tỉnh/Thành phố/Quận/Huyện/Xã/Phường)

* **Đối với Điểm đón (Pickup):**
  * Không dùng tọa độ trung tâm hành chính làm pickup. Bot hỏi thẳng thông tin chi tiết hơn:
    * *"Dạ, anh/chị đang ở đường nào hoặc tòa nhà/địa điểm nào thuộc [Tên Phường/Xã] ạ?"*

* **Đối với Điểm đến (Destination) - Quy tắc hỏi tối đa 1–2 câu chống ức chế:**
  1. *Lần 1 (Hỏi thăm dò nhẹ):* Khi khách chỉ nói xã/phường, bot hỏi đúng duy nhất 1 câu ngắn:
     * *"Dạ anh/chị có biết địa chỉ cụ thể hơn ở [Phường/Xã] không ạ?"*
  2. *Nếu khách nói "Không", "Không nhớ" hoặc từ chối:* DỪNG HỎI NGAY LẬP TỨC.
     * Lấy tọa độ trung tâm/đại diện của Xã/Phường + Tỉnh/TP làm destination.
     * Đánh dấu `destination.status = "confirmed"`.
     * Tiếp tục luồng tạo cuốc xe bình thường.
  3. *Nếu khách có cung cấp thêm thông tin nhưng Map API không xác định được (Not Found / Ambiguous):* Bot hỏi lại **lần cuối cùng (Lần 2)**:
     * *"Dạ hệ thống chưa định vị được điểm này, anh/chị có nhớ gần mốc nào lớn ở [Phường/Xã] không ạ?"*
  4. *Nếu khách vẫn không biết hoặc vẫn không xác định được:* Tự động fallback về tọa độ Xã/Phường + Tỉnh/TP, lưu chuỗi chi tiết khách mô tả vào `destination.note` để tài xế đọc khi đón, chuyển `destination.status = "confirmed"` và tiến hành tạo cuốc. Tuyệt đối không hỏi dồn sang lần thứ 3.

#### Trường hợp 2: Khách cung cấp tên Đường/Phố/Thôn nhưng thiếu số nhà

* **Đặc điểm:** *"Đón ở đường Nguyễn Trãi"*, *"Cho xe đến đường Hồ Tùng Mậu"*.
* Gửi chuỗi địa chỉ cho Map API kèm Location Biasing theo khu vực hoạt động.
* Nếu có nhiều kết quả trùng tên → hỏi trắc nghiệm ngắn để loại trừ.
* Nếu kết quả duy nhất:
  * Với **Pickup**: Không tự chốt tọa độ trung tâm cả tuyến đường. Hỏi thêm số nhà/ngõ/landmark hoặc vị trí cụ thể dễ tìm.
  * Với **Destination**: Chấp nhận luôn tên đường (ví dụ: *đường Hồ Tùng Mậu*, *đường Giải Phóng*) làm điểm đến mà không cần gặng hỏi số nhà, lấy tọa độ đại diện của tuyến đường và chuyển `destination.status = "confirmed"`.

#### Trường hợp 3: Khách cung cấp Số nhà/Ngõ/Ngách + Tên đường

* **Đặc điểm:** *"12 Nguyễn Trãi"*, *"Ngõ 55 Khương Trung"*.
* Không cần hỏi ngược lại xã/phường nếu Map API đã resolve duy nhất với độ tin cậy đủ cao.
* Bot đọc lại địa chỉ chuẩn hóa để xác nhận trước khi chuyển slot sang `confirmed`.

#### Trường hợp 4: Khách gọi tên địa danh bằng từ lóng/phiên âm/tên quen dùng

* **Đặc điểm:** Ocean Park 1, Vi Na Côn, Kengnam, Sân bay Nội Bài, Lăng Bác, Aeon Mall Hà Đông...
* Xây dựng **Local Alias DB** (từ đồng nghĩa, cách gọi quen, lỗi STT thường gặp).
* Thứ tự đề xuất:
  1. Tra Local Alias DB.
  2. Nếu match chắc chắn → lấy tên chuẩn + tọa độ/POI metadata.
  3. Nếu không match → gọi Map API/Fuzzy Search.
* Với điểm đến: Chốt ngay tọa độ POI, không đòi hỏi chi tiết cổng/sảnh nếu khách không chủ động nói.

#### Trường hợp 5: Khách cung cấp Điểm Neo / Điểm mốc (Landmark-based routing)

* **Đặc điểm:** *"Đối diện bảo tàng Phòng không Không quân"*, *"Bên trái trường tiểu học Minh Khai"*.
* NLP nhận diện từ chỉ hướng như `đối diện`, `bên trái`, `cổng sau`.
* Geocode **Điểm Neo**, không tạo tọa độ ảo cho vị trí đối diện/bên trái.
* Lưu phần chỉ hướng vào `note` để tài xế đọc được:
  * `Đón/Trả khách ở [từ chỉ hướng] + [điểm neo]`.

#### Trường hợp 6: Khách gọi xe theo thói quen / lịch sử cá nhân

* **Đặc điểm:** *"Cho chị một xe đến chỗ cũ nhé"*, *"Đón ở nhà nha em"*, *"Qua công ty anh lấy đồ"*.
* Dùng `customer_phone` truy vấn CRM, lấy 1-2 địa chỉ phù hợp nhất.
* Bot hỏi xác nhận địa chỉ gợi ý.
* Nếu khách từ chối → quay về luồng hỏi địa chỉ bình thường, không xóa các slot khác.

#### Trường hợp 7: Khách đứng tại điểm giao cắt (Ngã ba, Ngã tư)

* **Đặc điểm:** *"Đón ở ngã tư Sở"*, *"Ngã tư Khuất Duy Tiến giao Lê Văn Lương"*.
* Nhận diện từ khóa `ngã ba`, `ngã tư`, `giao với`.
* Query cụm giao cắt vào Map API.
* Nếu resolve duy nhất, có thể dùng làm pickup và thêm ghi chú để tài xế chủ động gọi khách khi tới giao lộ.

#### Trường hợp 8: Mega POI - quy tắc thống nhất

Mega POI là khu vực lớn có nhiều cổng/sảnh/tòa, ví dụ Times City, Ocean Park, bệnh viện lớn, sân bay.

Khi geocoding/Local DB xác định địa điểm là Mega POI, lưu `is_mega_poi = true` và metadata liên quan trong chính slot địa chỉ để các turn sau vẫn biết trạng thái này.

##### 8A. Mega POI là Điểm đến (Destination)

* Không ép khách cung cấp tòa/cổng cụ thể nếu họ không biết hoặc không muốn nói.
* Có thể chốt bằng `default_dropoff_point`/main gate/điểm đại diện đã cấu hình trong Local DB.
* Lưu `default_point_used = true` nếu dùng điểm mặc định.
* Tài xế có thể hỏi khách chi tiết khi gần tới nơi.

##### 8B. Mega POI là Điểm đón (Pickup)

Ưu tiên tìm vị trí cụ thể nhưng **không hỏi dồn**.

1. Nếu khách đã cung cấp sub-location rõ (cổng, sảnh, tòa, quán/điểm mốc) → geocode và xác nhận.
2. Nếu chưa rõ → bot chỉ hỏi **một lượt** câu hỏi hẹp/mở phù hợp, ví dụ:
   * *"Dạ khu vực này hơi rộng, anh/chị đang gần tòa, cổng hoặc quán nào dễ thấy để tài xế tìm mình ạ?"*
3. Nếu khách cung cấp được → cập nhật pickup và xác nhận.
4. Nếu khách không biết, từ chối trả lời hoặc tỏ ra khó chịu → dừng hỏi ngay.
5. Dùng `default_pickup_point` đã cấu hình sẵn cho Mega POI.
6. Gắn `default_point_used = true` và thêm cảnh báo/ghi chú để tài xế chủ động gọi khách.

> Quy tắc 8B **ghi đè** mọi rule chung kiểu “Mega POI bắt buộc phải hỏi đến khi có vị trí hẹp”. Pickup Mega POI chỉ được hỏi làm rõ tối đa một lượt trước khi fallback sang default pickup.

#### Trường hợp 9: Khách đang di chuyển hoặc không xác định được vị trí

* **Đặc điểm:** *"Anh đang đi bộ dọc đường hướng về Hà Đông"*, *"Chị không rõ đây là đâu, thấy trước mặt có cây xăng"*.
* Không hỏi dồn nhiều lượt.
* Nếu có landmark đủ dùng → thử xử lý theo Trường hợp 5.
* Nếu vẫn không thể xác định pickup đủ an toàn: Kích hoạt cơ chế **chuyển máy tổng đài viên** (`human_handoff`).

#### Trường hợp 10: Khách gõ sai/phát âm sai/nói ngọng/nhớ nhầm tên đường

* Dùng Fuzzy Search dựa trên khoảng cách chuỗi; Voice phase bổ sung độ tương đồng ngữ âm và lỗi STT.
* Nếu có candidate xác suất cao nhưng không chắc chắn tuyệt đối → đọc/hiển thị tên chuẩn để khách xác nhận.
* Không tự động ghi `confirmed` chỉ vì fuzzy match có điểm cao.

---

### 5.2. Các trường hợp kích hoạt chuyển máy cho tổng đài viên (Human Handoff)

Hệ thống sẽ dừng bot tự động, cập nhật trạng thái `booking_status = "operator_required"` và thực hiện hành động `action_type = "human_handoff"` trong 4 kịch bản cụ thể:

1. **Khách hàng chủ động yêu cầu:** Phát hiện ý định `request_operator` qua các câu nói như *"gặp tổng đài viên"*, *"nối máy cho nhân viên"*, *"cho gặp người thật"*.
2. **Không thể xác định Điểm đón an toàn (Pickup):** Rơi vào Trường hợp 9 khi khách đang di chuyển hoặc ở khu vực không có địa chỉ/điểm mốc rõ ràng sau lượt hỏi làm rõ.
3. **Vượt ngưỡng không hiểu (`fallback_count >= 2`):** Bot liên tiếp 2 lượt không thể trích xuất intent hoặc nhận diện được nội dung của khách (`unclear`). Cần chuyển máy ngay để tránh làm khách bực bội vì bot lặp lại câu hỏi.
4. **Sự cố kỹ thuật / Lỗi dịch vụ (`tool_status == "API_ERROR"`):** Map API hoặc dịch vụ định vị/tính cước gặp sự cố, hệ thống không thể tự geocode hoặc xử lý thông tin chuyến đi.

---

## 6. Thiết kế BotState

```python
from typing import Any, Dict, List, Literal, Optional
from typing_extensions import TypedDict


Intent = Literal[
    "provide_info",
    "confirm",
    "deny",
    "ask_question",
    "change_info",
    "cancel",
    "chit_chat",
    "unclear",
    "repeat_request",
    "request_operator",  # Khách chủ động yêu cầu gặp tổng đài viên
]

SlotStatus = Literal[
    "empty",
    "extracted",
    "confirmed",
    "needs_clarification",
]


class Coordinates(TypedDict):
    lat: float
    lng: float


class AddressComponents(TypedDict, total=False):
    detail: Optional[str]
    street: Optional[str]
    ward: Optional[str]
    district: Optional[str]
    province_city: Optional[str]


class AddressSlot(TypedDict):
    raw: Optional[str]
    formatted: Optional[str]
    coords: Optional[Coordinates]
    components: Optional[AddressComponents]

    # Thông tin tìm khách / landmark / ghi chú lộ trình
    note: Optional[str]

    # Mega POI
    is_mega_poi: bool
    default_point_used: bool

    # Trạng thái slot
    status: SlotStatus


class StopoverSlot(TypedDict):
    address: AddressSlot
    order: int


class ValueSlot(TypedDict):
    value: Any
    status: SlotStatus


class RouteResult(TypedDict):
    success: bool
    distance_km: Optional[float]
    duration_minutes: Optional[float]
    waypoints_count: int


class BookingSlots(TypedDict):
    # Bộ 4 Slot cốt lõi
    pickup: AddressSlot
    destination: AddressSlot
    pickup_time: ValueSlot
    vehicle_type: ValueSlot  # value: "xe_may" | "oto_4_cho" | "oto_7_cho"

    # Slot tùy chọn (không bắt buộc)
    stopovers: List[StopoverSlot]
    passengers: ValueSlot
    general_note: Optional[str]

    # Dữ liệu hành trình ước tính
    distance_km: Optional[float]
    duration_minutes: Optional[float]


class ExtractedSlotUpdate(TypedDict):
    slot_name: str
    value: Any
    source_text: str


class BotAction(TypedDict):
    action_type: Literal[
        "ask_slot",
        "confirm_slots",
        "confirm_booking",
        "clarify_address",
        "answer_question",
        "inform_success",
        "general_reply",
        "confirm_cancel",
        "human_handoff",  # Chuyển máy cho tổng đài viên
    ]

    # Có thể tác động/xác nhận nhiều slot trong một lượt.
    target_slots: List[str]
    metadata: Optional[Dict[str, Any]]


class BotState(TypedDict):
    # Phiên & khách hàng
    session_id: str                 # UUID riêng cho từng phiên
    customer_phone: str             # Khóa tra CRM, không phải Session ID
    customer_name: str              # Bắt buộc ở MVP theo luồng khởi tạo
    messages: List[Dict[str, str]]

    # Trạng thái nghiệp vụ
    booking_slots: BookingSlots
    turn_extracted_slots: List[ExtractedSlotUpdate]

    # Multi-intent: một turn có thể chứa nhiều intent
    intents: List[Intent]
    primary_intent: Optional[Intent]

    # Điều phối
    current_focus: Optional[str]
    last_bot_action: Optional[BotAction]
    tool_status: Optional[
        Literal["SUCCESS", "NOT_FOUND", "AMBIGUOUS", "API_ERROR"]
    ]
    fallback_count: int             # Số lần không hiểu liên tiếp (>= 2 sẽ handoff)

    # Trạng thái vòng đời booking
    booking_status: Literal[
        "collecting",
        "confirming",
        "ready_to_book",
        "booked",
        "cancel_pending",
        "canceled",
        "operator_required",        # Chờ chuyển máy tổng đài viên
    ]

    final_response_text: Optional[str]
```

---

## 7. Quy tắc xác định `ready_to_book`

Không nên duy trì `is_ready_to_book` như một cờ được set tùy ý ở nhiều nơi. Nên **tính ra (derived state)** từ dữ liệu hiện tại để tránh state lệch.

Một booking được coi là `ready_to_book` và có thể tạo cuốc xe ngay khi hội đủ các điều kiện sau:

* `pickup.status == "confirmed"` (phải xác định được vị trí đón cụ thể hoặc default pickup point có cảnh báo).
* `destination.status == "confirmed"` (chấp nhận địa chỉ cụ thể, tên trục đường, Mega POI, hoặc tối thiểu Xã/Phường + Tỉnh/Thành phố sau tối đa 1-2 câu hỏi làm rõ).
* `pickup_time.status == "confirmed"`.
* `vehicle_type.status == "confirmed"`.
* Không có địa chỉ bắt buộc nào đang bị kẹt ở trạng thái `needs_clarification`.
* Nếu pickup dùng Mega POI default point thì `default_point_used == true` và đã có note/cảnh báo cần thiết cho tài xế.

Các thông tin `passengers`, `stopovers`, `general_note` là **hoàn toàn tùy chọn**; nếu khách không chủ động yêu cầu thì hệ thống bỏ qua và không cản trở việc tạo cuốc xe.

---

## 8. Nguyên tắc ưu tiên khi các rule cùng match

Khi một câu có thể rơi vào nhiều rule, áp dụng theo thứ tự ưu tiên sau:

1. `request_operator` / Phát hiện sự cố cần chuyển máy tổng đài viên (`human_handoff`)
2. `cancel` / xác nhận hủy cuốc
3. `change_info` và entity mới trong turn
4. `confirm` / `deny` gắn với `last_bot_action`
5. Rule an toàn/khả năng tìm khách của pickup (không chấp nhận điểm đón chung chung ở cấp xã/phường)
6. Rule linh hoạt của destination (chấp nhận xã/phường + tỉnh/thành, tối đa 1-2 câu làm rõ)
7. Rule Mega POI (8A/8B)
8. Geocoding/Fuzzy/Local Alias DB
9. `ask_question` (RAG/Tools/Session)
10. `chit_chat`
11. Hỏi slot bắt buộc còn thiếu tiếp theo

Mục tiêu của thứ tự này là **không làm mất entity hợp lệ**, không xóa nhầm slot, không gặng hỏi gây phiền hà khách hàng, và đảm bảo cuốc xe được chốt nhanh chóng ngay khi có đủ thông tin tối thiểu.

## 9. Ví dụ end-to-end chuẩn để hiểu toàn hệ thống

Ví dụ này không thay thế các rule chi tiết; nó cho thấy các thành phần phối hợp với nhau như thế nào.

### Turn 0 — khởi tạo

```text
CLI yêu cầu:
Số điện thoại: 09xxxxxxxx
Tên: Minh
```

Hệ thống tạo một `session_id` UUID mới, nạp lịch sử CRM theo `customer_phone` nếu có và khởi tạo `booking_status="collecting"`.

### Turn 1 — khách cung cấp nhiều slot cùng lúc

```text
USER> Đón anh ở 12 Nguyễn Trãi đi Nội Bài, xe 4 chỗ, đi ngay.
```

Kết quả mong đợi:

- `intents = ["provide_info"]`
- `pickup.raw = "12 Nguyễn Trãi"`
- `destination.raw = "Nội Bài"`
- `vehicle_type.value = "oto_4_cho"`
- `pickup_time.value = "now"`
- Resolver xử lý pickup/destination.
- Không hỏi `passengers`, `stopovers`, `general_note`.

Nếu pickup và destination resolve đủ chắc chắn, bot có thể chuyển sang bước xác nhận booking.

### Turn 2 — khách sửa đúng một slot và hỏi FAQ

```text
USER> À đổi sang 7 chỗ nhé, mà giá bao nhiêu một cây?
```

Kết quả mong đợi:

- `intents` chứa cả `change_info` và `ask_question`.
- Chỉ `vehicle_type` đổi thành `oto_7_cho`.
- Pickup, destination và pickup_time giữ nguyên.
- Bot trả lời giá/km từ KB rồi tiếp tục flow đặt xe.

### Turn 3 — xác nhận

```text
BOT> Anh đi từ 12 Nguyễn Trãi đến Sân bay Nội Bài, đi ngay, xe 7 chỗ đúng không ạ?
USER> Đúng rồi.
```

`confirm` chỉ tác động vào các slot nằm trong `last_bot_action.target_slots`. Sau khi đủ điều kiện `ready_to_book`, booking được tạo đúng một lần và `booking_status="booked"`.

### Biến thể lỗi kỹ thuật

Nếu Map API trả `API_ERROR` trong quá trình trên, bot **không** được nói rằng địa chỉ của khách sai. Phiên phải chuyển `operator_required` và phát `human_handoff`.

---


---

# PHẦN II — KẾ HOẠCH TRIỂN KHAI VÀ KIỂM THỬ

Phần này chuyển toàn bộ đặc tả ở Phần I thành phương án kỹ thuật, state invariant, test plan, milestone và tiêu chí nghiệm thu. Mục tiêu là để một team mới có thể bắt tay triển khai mà không cần tài liệu tham chiếu khác.

# 1. Mục tiêu và tiêu chí thành công của MVP

MVP phải chứng minh được một vòng đời đặt xe hoàn chỉnh qua Text CLI: khởi tạo phiên → hiểu yêu cầu → thu thập/chuẩn hóa 4 slot cốt lõi → xử lý hỏi đáp/sửa đổi → xác nhận → tạo booking hoặc chuyển trạng thái operator_required khi bot không thể xử lý an toàn.

[YÊU CẦU NGHIỆP VỤ] Bộ 4 slot cốt lõi gồm pickup, destination, pickup_time và vehicle_type. Passengers, stopovers và general_note là tùy chọn và không được cản trở việc tạo cuốc.

| **Mục tiêu**           | **Tiêu chí nghiệm thu MVP**                                                                                                        |
|------------------------|------------------------------------------------------------------------------------------------------------------------------------|
| Hoàn thành cuốc        | Khi 4 slot cốt lõi ở trạng thái confirmed và không có địa chỉ bắt buộc needs_clarification, hệ thống tạo booking và chuyển booked. |
| Không hỏi thừa         | Không chủ động hỏi passengers/stopovers/general_note khi khách không nêu.                                                          |
| Không mất dữ liệu      | Một turn multi-intent phải giữ toàn bộ entity hợp lệ; deny/change_info chỉ tác động đúng slot.                                     |
| Địa chỉ thực dụng      | Pickup phải đủ để tìm khách; destination có thể chấp nhận tên đường/Mega POI/xã-phường + tỉnh-thành theo rule fallback.            |
| Chống lặp gây ức chế   | Không hỏi quá giới hạn làm rõ đã quy định; fallback_count >= 2, API_ERROR hoặc pickup không xác định an toàn phải handoff.        |
| Có thể regression test | Mọi rule quan trọng có test hội thoại và state assertion tự động.                                                                  |

# 2. Phạm vi MVP và những gì chưa làm

## 2.1. Trong phạm vi

- CLI nhập số điện thoại và tên khách để khởi tạo session_id mới.

- NLU/LLM extraction cho multi-intent và entity/slot trong từng turn.

- BotState, slot status, last_bot_action, fallback_count và booking lifecycle.

- Address resolver: alias/fuzzy/geocoding adapter; hỗ trợ rule pickup, destination, landmark, giao cắt, Mega POI.

- FAQ/RAG tối thiểu cho thông tin tĩnh như giá/km và chính sách dịch vụ.

- CRM adapter tối thiểu để giả lập/đọc địa chỉ quen theo customer_phone.

- Booking repository/service để tạo booking khi ready_to_book.

- Human handoff ở mức logic: cập nhật operator_required + action human_handoff + thông báo CLI.

- Bộ test tự động unit + conversation regression + lỗi tích hợp.

## 2.2. Ngoài phạm vi

- Speech-to-Text, Text-to-Speech, Caller ID, quản lý cuộc gọi, chuyển line thật.

- Tính giá trọn gói trước chuyến; MVP chỉ trả lời giá/km theo knowledge base.

- Dispatch tài xế thật, tracking tài xế, thanh toán, khuyến mại, ví điện tử.

- Tối ưu mô hình AI quy mô production, autoscaling, HA/DR.

> **Quy ước CLI cho `human_handoff`**  
> Trong MVP CLI, handoff không chuyển cuộc gọi thật. Hệ thống phải kết thúc luồng bot bằng `booking_status="operator_required"`, `action_type="human_handoff"` và in lý do handoff. Đây là điểm nghiệm thu logic để thay adapter Voice sau này.

# 3. Kiến trúc triển khai đề xuất cho MVP CLI

[PHƯƠNG ÁN TRIỂN KHAI] Giữ domain logic độc lập adapter như đặc tả nghiệp vụ trong tài liệu này yêu cầu. CLI chỉ là lớp vào/ra; mọi rule hội thoại nằm trong orchestration/dialog policy để sau này thay CLI bằng Voice mà không viết lại nghiệp vụ.

| **Module**       | **Trách nhiệm chính**                                                                          | **Đầu vào / đầu ra**                    |
|------------------|------------------------------------------------------------------------------------------------|-----------------------------------------|
| cli_app          | Khởi tạo session, đọc text, hiển thị final_response_text, in trạng thái debug tùy cấu hình.    | stdin → turn request; BotState → stdout |
| session_service  | Tạo UUID session_id, nạp CRM theo customer_phone, lưu message/action/state.                    | phone/name → BotState                   |
| nlu_extractor    | Trích intents\[\], primary_intent và turn_extracted_slots; không tự quyết định booking.        | text + context → structured extraction  |
| state_reducer    | Áp dụng entity/change/confirm/deny theo đúng last_bot_action; không xóa mù.                    | state + extraction → state mới          |
| address_resolver | Alias → fuzzy → Map API; trả SUCCESS/NOT_FOUND/AMBIGUOUS/API_ERROR và metadata Mega POI.       | AddressSlot raw → normalized result     |
| dialog_policy    | Chọn action tiếp theo dựa trên priority rules, clarification budget, missing slots và handoff. | BotState → BotAction                    |
| qa_router        | Route FAQ tĩnh / tool động / session question.                                                 | ask_question → answer                   |
| booking_service  | Tính ready_to_book (derived); tạo booking đúng một lần.                                        | confirmed slots → booking_id            |
| repositories     | Lưu session/messages/bookings; MVP có thể dùng SQLite hoặc JSON persistence.                   | domain objects ↔ storage                |
| test_harness     | Chạy conversation fixtures và assert state/action/response pattern.                            | YAML/JSON fixtures → test results       |

## 3.1. Cấu trúc thư mục gợi ý

> src/  
> cli.py  
> domain/models.py  
> domain/ready_to_book.py  
> nlu/extractor.py  
> dialogue/orchestrator.py  
> dialogue/policy.py  
> dialogue/state_reducer.py  
> address/resolver.py  
> address/alias_db.py  
> qa/router.py  
> adapters/map_provider.py  
> adapters/crm_provider.py  
> adapters/kb_provider.py  
> repositories/session_repo.py  
> repositories/booking_repo.py  
> services/booking_service.py  
> tests/  
> unit/  
> conversation/  
> fixtures/  
> failure_injection/

# 4. Luồng xử lý chuẩn của một turn

[YÊU CẦU NGHIỆP VỤ] Thứ tự xử lý phải ưu tiên không mất entity: bóc tách đầy đủ → áp dụng thay đổi → confirm/deny theo last_bot_action → trả lời câu hỏi → cancel/handoff → chọn câu hỏi tiếp theo.

1.  Nhận user_text, append vào messages.

2.  NLU trích toàn bộ intents + entity; nếu intent chính unclear nhưng có entity hợp lệ thì vẫn giữ entity.

3.  Áp dụng change_info/giá trị sửa cuối cùng trước khi ghi state.

4.  Áp dụng confirm/deny chỉ lên last_bot_action.target_slots.

5.  Chuẩn hóa các address slot vừa thay đổi qua address_resolver khi cần.

6.  Trả lời ask_question nhưng không làm rơi slot vừa trích được.

7.  Kiểm tra handoff/cancel theo priority.

8.  Tính derived ready_to_book từ state hiện tại.

9.  Nếu ready → confirm_booking hoặc create booking theo policy; nếu chưa → hỏi đúng slot cần thiết tiếp theo.

10. Lưu BotAction, state và final_response_text.

> process_turn(state, user_text):  
> extraction = nlu.extract(user_text, state)  
> state = reducer.apply_entities_and_changes(state, extraction)  
> state = reducer.apply_confirm_deny(state, extraction, state.last_bot_action)  
> state = resolve_changed_addresses(state)  
> answer = qa_router.answer_if_needed(state, extraction)  
> if should_handoff(state, extraction): return handoff(state, reason)  
> if should_cancel_flow(state, extraction): return cancel_flow(state)  
> if ready_to_book(state): return booking_flow(state, answer)  
> return ask_next_required_slot_or_clarification(state, answer)

# 5. Quy tắc state và invariant bắt buộc

| **Invariant**                              | **Yêu cầu kiểm thử**                                                                                                 |
|--------------------------------------------|----------------------------------------------------------------------------------------------------------------------|
| I-01: confirmed không tự mất               | Slot confirmed chỉ thay đổi khi khách sửa trực tiếp, deny đúng slot, hoặc hệ thống có rule invalidate rõ ràng.       |
| I-02: deny không reset toàn bộ             | Nếu bot vừa hỏi nhiều slot và khách nói “không”, state giữ nguyên cho đến khi xác định slot cần sửa.                 |
| I-03: entity hợp lệ luôn được giữ          | Ngay cả khi turn là unclear/ask_question/chit_chat, entity hợp lệ trong cùng câu vẫn phải cập nhật.                  |
| I-04: ready_to_book là derived             | Không set cờ rời rạc; mỗi turn tính lại từ 4 slot + needs_clarification.                                             |
| I-05: optional không block                 | passengers/stopovers/general_note không được tham gia điều kiện ready_to_book nếu khách không chủ động nêu.          |
| I-06: clarification có ngân sách           | Destination vùng rộng tối đa theo rule 1-2 lượt; Mega POI pickup tối đa 1 lượt; fallback unclear 2 lượt thì handoff. |
| I-07: API_ERROR không biến thành lỗi khách | Lỗi tool phải dẫn đến handoff, không yêu cầu khách lặp địa chỉ vô hạn.                                               |
| I-08: booking idempotent                   | Cùng một state/turn không được tạo hai booking_id nếu user bấm/nhập xác nhận lặp.                                    |

# 6. Kế hoạch xử lý từng slot cốt lõi

## 6.1. Pickup

- Chỉ confirmed khi đủ để tài xế tìm khách, hoặc dùng default_pickup_point của Mega POI theo rule.

- Không dùng tọa độ trung tâm xã/phường hoặc tuyến đường quá rộng làm pickup.

- Tên đường không số nhà → hỏi số nhà/ngõ/landmark/vị trí dễ thấy.

- Landmark/đối diện/bên trái → geocode điểm neo, giữ phần chỉ hướng trong note.

- Giao cắt resolve duy nhất có thể làm pickup và thêm note để tài xế gọi khi tới.

- Khách đang di chuyển/không xác định được vị trí → một lượt làm rõ; nếu vẫn không an toàn thì handoff.

## 6.2. Destination

- Chấp nhận mức chi tiết thấp hơn pickup.

- Tên đường duy nhất → confirmed, không hỏi số nhà.

- Mega POI → confirmed bằng POI/default_dropoff_point; không ép cổng/sảnh.

- Xã/phường + tỉnh/thành → hỏi thăm dò tối đa theo rule; nếu khách không biết/từ chối thì fallback tọa độ đại diện và confirmed.

- Nếu khách đưa chi tiết nhưng geocoder không resolve → chỉ hỏi mốc lớn lần cuối rồi fallback, không hỏi lần ba.

## 6.3. Pickup time

[PHƯƠNG ÁN TRIỂN KHAI] Chuẩn hóa về hai dạng: now hoặc timestamp cụ thể. Nếu câu “đi ngay/bây giờ” → confirmed=now. Nếu thời gian mơ hồ kiểu “chiều mai” mà kiến trúc chưa nêu rule chi tiết, MVP nên đưa về needs_clarification và hỏi một câu ngắn; không tự suy diễn giờ cụ thể.

## 6.4. Vehicle type

Chỉ cho phép xe_may, oto_4_cho, oto_7_cho. Khi khách nói “4 chỗ, à thôi 7 chỗ” thì lấy giá trị cuối cùng trong turn. Nếu đổi xe sau khi đã confirmed, chỉ reset/confirm lại vehicle_type, không ảnh hưởng địa chỉ và thời gian.

# 7. Chính sách hội thoại chống ức chế

| **Rule**                     | **Cách triển khai**                                                                         | **Chỉ báo lỗi nếu vi phạm**                                 |
|------------------------------|---------------------------------------------------------------------------------------------|-------------------------------------------------------------|
| Không hỏi thông tin tùy chọn | Policy chỉ chọn ask_slot từ 4 slot cốt lõi; optional chỉ extract khi khách tự nói.          | Bot hỏi số người/điểm dừng/ghi chú khi không cần.           |
| Không bắt khách nói lại      | Confirmed slot được bảo toàn; response không hỏi lại slot đã có trừ khi khách phủ định/sửa. | Khách phải lặp địa chỉ/loại xe đã xác nhận.                 |
| Một lỗi tool ≠ lỗi khách     | tool_status API_ERROR kích hoạt handoff.                                                    | Bot nói “địa chỉ sai” khi API timeout.                      |
| Giới hạn làm rõ              | Lưu metadata clarification_count theo address slot.                                         | Bot hỏi lần 3 về destination hoặc lần 2 về Mega POI pickup. |
| Biết dừng                    | fallback_count tăng ở unclear thật sự; reset về 0 khi turn hiểu được. >=2 → handoff.       | Bot lặp “vui lòng nói lại” vô hạn.                          |
| Trả lời rồi quay lại booking | ask_question không đổi current booking context.                                             | Sau FAQ bot quên slot còn thiếu.                            |
| Sửa cục bộ                   | change_info/deny target slot, không reset booking.                                          | Sửa xe nhưng bị hỏi lại pickup.                             |

# 8. Kế hoạch xử lý các tình huống thực tế rủi ro cao

Phần này chuyển các cảnh báo UX thành testable behavior. Mỗi case cần tồn tại ít nhất một conversation regression test và một assertion trên BotState.

## TC-R01 - Khách đã đủ 4 slot nhưng bot hỏi passengers/stopovers/notes

| **Thuộc tính**              | **Chi tiết**                                                                                |
|-----------------------------|---------------------------------------------------------------------------------------------|
| Ưu tiên                     | P0                                                                                          |
| Điều kiện nhận diện         | Phát hiện 4 slot core đủ/confirmed. Optional đang empty.                                    |
| Phương hướng xử lý          | Không hỏi optional; chuyển confirm/create booking.                                          |
| State/action mong đợi       | ready_to_book=True; action=confirm_booking hoặc inform_success.                             |
| Conversation test tối thiểu | “Cho anh xe 4 chỗ từ 12 Nguyễn Trãi ra Nội Bài, đi ngay.” → không được hỏi “đi mấy người?”. |

## TC-R02 - Destination chỉ là tên đường

| **Thuộc tính**              | **Chi tiết**                                                  |
|-----------------------------|---------------------------------------------------------------|
| Ưu tiên                     | P0                                                            |
| Điều kiện nhận diện         | destination.raw là tên đường, Map API resolve duy nhất.       |
| Phương hướng xử lý          | Chấp nhận tọa độ đại diện tuyến đường; destination=confirmed. |
| State/action mong đợi       | Không phát sinh hỏi số nhà destination.                       |
| Conversation test tối thiểu | “Đi đường Hồ Tùng Mậu.” → tiếp tục slot khác.                 |

## TC-R03 - Destination chỉ xã/phường và khách không biết chi tiết

| **Thuộc tính**              | **Chi tiết**                                                        |
|-----------------------------|---------------------------------------------------------------------|
| Ưu tiên                     | P0                                                                  |
| Điều kiện nhận diện         | Lần hỏi thăm dò đầu; user nói không/không nhớ/từ chối.              |
| Phương hướng xử lý          | Dừng hỏi ngay; fallback tọa độ xã/phường + tỉnh/thành; note nếu có. |
| State/action mong đợi       | destination.status=confirmed; clarification_count không tăng tiếp.  |
| Conversation test tối thiểu | Bot hỏi một lần; khách “không nhớ” → tiếp tục booking.              |

## TC-R04 - Destination geocode thất bại sau khi khách bổ sung chi tiết

| **Thuộc tính**              | **Chi tiết**                                                   |
|-----------------------------|----------------------------------------------------------------|
| Ưu tiên                     | P0                                                             |
| Điều kiện nhận diện         | NOT_FOUND/AMBIGUOUS sau lần làm rõ đầu.                        |
| Phương hướng xử lý          | Hỏi mốc lớn đúng một lần cuối; nếu vẫn fail thì fallback vùng. |
| State/action mong đợi       | Tối đa 2 lượt clarification; không có lượt 3.                  |
| Conversation test tối thiểu | Không rơi vào vòng lặp địa chỉ.                                |

## TC-R05 - Mega POI pickup không biết cổng/tòa

| **Thuộc tính**              | **Chi tiết**                                                                               |
|-----------------------------|--------------------------------------------------------------------------------------------|
| Ưu tiên                     | P0                                                                                         |
| Điều kiện nhận diện         | is_mega_poi=true, pickup chưa có sub-location.                                             |
| Phương hướng xử lý          | Hỏi một lượt hẹp; nếu user không biết/tỏ khó chịu → default_pickup_point + note gọi khách. |
| State/action mong đợi       | pickup.confirmed; default_point_used=true.                                                 |
| Conversation test tối thiểu | “Đón ở Times City.” / “Không biết cổng.” → dùng điểm mặc định.                             |

## TC-R06 - Sửa một slot trong câu phủ định

| **Thuộc tính**              | **Chi tiết**                                                 |
|-----------------------------|--------------------------------------------------------------|
| Ưu tiên                     | P0                                                           |
| Điều kiện nhận diện         | last_bot_action xác nhận nhiều slot; user “Không, xe 7 chỗ.” |
| Phương hướng xử lý          | Chỉ update vehicle_type=oto_7_cho; giữ các slot khác.        |
| State/action mong đợi       | pickup/destination/time unchanged.                           |
| Conversation test tối thiểu | Không được hỏi lại điểm đón.                                 |

## TC-R07 - Khách chỉ nói “không” khi đang xác nhận nhiều slot

| **Thuộc tính**              | **Chi tiết**                                                         |
|-----------------------------|----------------------------------------------------------------------|
| Ưu tiên                     | P0                                                                   |
| Điều kiện nhận diện         | deny, không có replacement entity.                                   |
| Phương hướng xử lý          | Không xóa slot; hỏi ngắn slot nào cần sửa.                           |
| State/action mong đợi       | State giữ nguyên; action=clarification về slot cần sửa.              |
| Conversation test tối thiểu | “Không.” → “Anh muốn sửa điểm đón, điểm đến, thời gian hay loại xe?” |

## TC-R08 - Một câu có nhiều intent

| **Thuộc tính**              | **Chi tiết**                                                          |
|-----------------------------|-----------------------------------------------------------------------|
| Ưu tiên                     | P0                                                                    |
| Điều kiện nhận diện         | Cùng turn có provide_info + change_info + ask_question.               |
| Phương hướng xử lý          | Extract tất cả; apply change; trả lời FAQ; sau đó hỏi slot còn thiếu. |
| State/action mong đợi       | Không mất pickup/vehicle; question được trả lời.                      |
| Conversation test tối thiểu | “Đón 12 Nguyễn Trãi, đổi 7 chỗ, giá/km bao nhiêu?”                    |

## TC-R09 - Khách hỏi FAQ giữa quá trình đặt xe

| **Thuộc tính**              | **Chi tiết**                                                   |
|-----------------------------|----------------------------------------------------------------|
| Ưu tiên                     | P1                                                             |
| Điều kiện nhận diện         | ask_question trong session đang collecting.                    |
| Phương hướng xử lý          | Trả lời ngắn, giữ state rồi resume current_focus/missing slot. |
| State/action mong đợi       | booking_status vẫn collecting; slot cũ giữ nguyên.             |
| Conversation test tối thiểu | Sau giá/km, bot quay lại hỏi destination.                      |

## TC-R10 - Alias/tên quen/STT-like typo

| **Thuộc tính**              | **Chi tiết**                                                          |
|-----------------------------|-----------------------------------------------------------------------|
| Ưu tiên                     | P1                                                                    |
| Điều kiện nhận diện         | Local Alias hoặc fuzzy có match chắc chắn/candidate.                  |
| Phương hướng xử lý          | Alias chắc chắn → normalize; fuzzy chưa chắc → hỏi confirm tên chuẩn. |
| State/action mong đợi       | Không confirmed tự động khi fuzzy chưa chắc.                          |
| Conversation test tối thiểu | “Kengnam” → Keangnam; đọc lại nếu cần.                                |

## TC-R11 - Fuzzy match sai nhưng score cao

| **Thuộc tính**              | **Chi tiết**                                               |
|-----------------------------|------------------------------------------------------------|
| Ưu tiên                     | P0                                                         |
| Điều kiện nhận diện         | candidate high-score nhưng không tuyệt đối.                |
| Phương hướng xử lý          | status=needs_clarification; bot đọc candidate để xác nhận. |
| State/action mong đợi       | Không tạo booking trước confirm.                           |
| Conversation test tối thiểu | Tránh tài xế đến sai địa chỉ.                              |

## TC-R12 - Pickup chỉ cấp xã/phường

| **Thuộc tính**              | **Chi tiết**                                    |
|-----------------------------|-------------------------------------------------|
| Ưu tiên                     | P0                                              |
| Điều kiện nhận diện         | pickup resolve tới vùng rộng.                   |
| Phương hướng xử lý          | Không confirmed; hỏi đường/tòa/địa điểm cụ thể. |
| State/action mong đợi       | pickup.status=needs_clarification.              |
| Conversation test tối thiểu | Không lấy tâm phường làm điểm đón.              |

## TC-R13 - Khách đang di chuyển, pickup không xác định

| **Thuộc tính**              | **Chi tiết**                                            |
|-----------------------------|---------------------------------------------------------|
| Ưu tiên                     | P0                                                      |
| Điều kiện nhận diện         | Sau lượt làm rõ/landmark vẫn không đủ an toàn.          |
| Phương hướng xử lý          | human_handoff.                                          |
| State/action mong đợi       | booking_status=operator_required; action=human_handoff. |
| Conversation test tối thiểu | Không hỏi địa chỉ lần nữa.                              |

## TC-R14 - Hai lượt liên tiếp bot không hiểu

| **Thuộc tính**              | **Chi tiết**                             |
|-----------------------------|------------------------------------------|
| Ưu tiên                     | P0                                       |
| Điều kiện nhận diện         | fallback_count đạt 2.                    |
| Phương hướng xử lý          | Handoff ngay; không hỏi “nói lại” lần 3. |
| State/action mong đợi       | operator_required.                       |
| Conversation test tối thiểu | Test chính xác counter/reset.            |

## TC-R15 - Map API/API định vị lỗi

| **Thuộc tính**              | **Chi tiết**                                         |
|-----------------------------|------------------------------------------------------|
| Ưu tiên                     | P0                                                   |
| Điều kiện nhận diện         | tool_status=API_ERROR.                               |
| Phương hướng xử lý          | Handoff; thông báo lỗi hệ thống, không đổ lỗi input. |
| State/action mong đợi       | operator_required; reason=api_error.                 |
| Conversation test tối thiểu | Failure injection timeout/500.                       |

## TC-R16 - Khách yêu cầu gặp người thật

| **Thuộc tính**              | **Chi tiết**                    |
|-----------------------------|---------------------------------|
| Ưu tiên                     | P0                              |
| Điều kiện nhận diện         | intent request_operator.        |
| Phương hướng xử lý          | Ưu tiên cao nhất; handoff ngay. |
| State/action mong đợi       | operator_required.              |
| Conversation test tối thiểu | “Cho tôi gặp tổng đài viên.”    |

## TC-R17 - Khách nói “chỗ cũ/nhà/công ty”

| **Thuộc tính**              | **Chi tiết**                                                                                |
|-----------------------------|---------------------------------------------------------------------------------------------|
| Ưu tiên                     | P1                                                                                          |
| Điều kiện nhận diện         | CRM có 1-2 địa chỉ phù hợp.                                                                 |
| Phương hướng xử lý          | Gợi ý địa chỉ và hỏi confirm; nếu deny thì quay về hỏi địa chỉ thường, không xóa slot khác. |
| State/action mong đợi       | last_bot_action.target_slots=\[pickup hoặc destination\].                                   |
| Conversation test tối thiểu | CRM fixture có địa chỉ quen.                                                                |

## TC-R18 - Khách nói landmark có chỉ hướng

| **Thuộc tính**              | **Chi tiết**                                                   |
|-----------------------------|----------------------------------------------------------------|
| Ưu tiên                     | P1                                                             |
| Điều kiện nhận diện         | Nhận diện “đối diện/bên trái/cổng sau” + POI.                  |
| Phương hướng xử lý          | Geocode điểm neo, lưu chỉ hướng vào note; không tạo tọa độ ảo. |
| State/action mong đợi       | coords=POI; note chứa chỉ hướng.                               |
| Conversation test tối thiểu | “Đối diện bảo tàng…”                                           |

## TC-R19 - Ngã tư/giao cắt resolve duy nhất

| **Thuộc tính**              | **Chi tiết**                                   |
|-----------------------------|------------------------------------------------|
| Ưu tiên                     | P1                                             |
| Điều kiện nhận diện         | Map API trả giao cắt duy nhất.                 |
| Phương hướng xử lý          | Cho phép pickup; thêm note chủ động gọi khách. |
| State/action mong đợi       | pickup=confirmed.                              |
| Conversation test tối thiểu | “Ngã tư Khuất Duy Tiến giao Lê Văn Lương.”     |

## TC-R20 - Giá trị sửa cuối cùng trong cùng turn

| **Thuộc tính**              | **Chi tiết**                                  |
|-----------------------------|-----------------------------------------------|
| Ưu tiên                     | P1                                            |
| Điều kiện nhận diện         | Một slot xuất hiện nhiều giá trị theo thứ tự. |
| Phương hướng xử lý          | Lấy giá trị cuối cùng có ý nghĩa sửa.         |
| State/action mong đợi       | vehicle_type=oto_7_cho.                       |
| Conversation test tối thiểu | “4 chỗ, à thôi 7 chỗ.”                        |

## TC-R21 - Unclear nhưng có entity hợp lệ

| **Thuộc tính**              | **Chi tiết**                                                                          |
|-----------------------------|---------------------------------------------------------------------------------------|
| Ưu tiên                     | P1                                                                                    |
| Điều kiện nhận diện         | Intent unclear + trích được slot rõ.                                                  |
| Phương hướng xử lý          | Cập nhật slot; tăng fallback_count nếu thực sự không hiểu phần chính; hỏi phần thiếu. |
| State/action mong đợi       | Entity không bị bỏ.                                                                   |
| Conversation test tối thiểu | Câu lộn xộn nhưng có “Nội Bài”.                                                       |

## TC-R22 - Cancel rồi đổi ý không hủy

| **Thuộc tính**              | **Chi tiết**                                 |
|-----------------------------|----------------------------------------------|
| Ưu tiên                     | P1                                           |
| Điều kiện nhận diện         | cancel → confirm_cancel; user deny.          |
| Phương hướng xử lý          | Quay lại collecting/confirming với state cũ. |
| State/action mong đợi       | Không mất slots.                             |
| Conversation test tối thiểu | “Hủy đi” / “À thôi không hủy.”               |

## TC-R23 - Repeat request

| **Thuộc tính**              | **Chi tiết**                                           |
|-----------------------------|--------------------------------------------------------|
| Ưu tiên                     | P2                                                     |
| Điều kiện nhận diện         | intent repeat_request.                                 |
| Phương hướng xử lý          | Đọc lại slot cụ thể hoặc summary; không thay đổi slot. |
| State/action mong đợi       | State unchanged.                                       |
| Conversation test tối thiểu | “Nãy tôi đặt đi đâu nhỉ?”                              |

## TC-R24 - Booking create bị gọi lặp

| **Thuộc tính**              | **Chi tiết**                                                       |
|-----------------------------|--------------------------------------------------------------------|
| Ưu tiên                     | P0                                                                 |
| Điều kiện nhận diện         | User gửi lại “đúng”/CLI retry sau booked.                          |
| Phương hướng xử lý          | Idempotency theo booking/session state; không tạo booking thứ hai. |
| State/action mong đợi       | Một booking_id duy nhất.                                           |
| Conversation test tối thiểu | Double-confirm test.                                               |

# 9. Bộ test conversation regression tối thiểu

[PHƯƠNG ÁN TRIỂN KHAI] Test harness nên mô tả mỗi turn bằng input, tool mocks, expected response pattern và expected state patch. Không so khớp tuyệt đối toàn câu bot nếu dùng LLM; ưu tiên assert action, target_slots, slot values/status và các cụm ý bắt buộc.

| **ID** | **Kịch bản**                            | **Trạng thái cuối**   | **Assertion chính**          |
|--------|-----------------------------------------|-----------------------|------------------------------|
| C01    | Happy path đủ 4 slot trong 1 câu        | booked                | Không hỏi optional           |
| C02    | Thu thập từng slot qua 4 turn           | booked                | Không hỏi lại slot confirmed |
| C03    | Destination tên đường                   | collecting/booked     | destination confirmed ngay   |
| C04    | Destination phường + “không biết”       | collecting/booked     | fallback confirmed sau 1 hỏi |
| C05    | Destination ambiguous rồi landmark fail | collecting/booked     | fallback sau tối đa 2 hỏi    |
| C06    | Pickup phường quá rộng                  | collecting            | pickup needs_clarification   |
| C07    | Pickup Mega POI + không biết cổng       | collecting/booked     | default_pickup_point         |
| C08    | Destination Mega POI                    | collecting/booked     | không hỏi cổng/sảnh          |
| C09    | Landmark + chỉ hướng                    | collecting            | note được giữ                |
| C10    | Ngã tư resolve duy nhất                 | collecting            | pickup confirmed             |
| C11    | Alias chính xác                         | collecting            | normalize thành POI chuẩn    |
| C12    | Fuzzy candidate cần xác nhận            | collecting            | needs_clarification          |
| C13    | Multi-intent provide/change/question    | collecting            | không mất entity             |
| C14    | Sửa vehicle sau confirm                 | confirming            | chỉ vehicle thay đổi         |
| C15    | Deny chung chung                        | confirming            | không reset slots            |
| C16    | Ask FAQ giữa flow                       | collecting            | resume slot thiếu            |
| C17    | Session question “đã chọn xe gì?”       | collecting            | trả lời từ state             |
| C18    | CRM “chỗ cũ” confirm yes                | collecting            | pickup từ CRM confirmed      |
| C19    | CRM “chỗ cũ” deny                       | collecting            | quay hỏi pickup thường       |
| C20    | Unclear \#1                             | collecting            | fallback_count=1             |
| C21    | Unclear \#2 liên tiếp                   | operator_required     | handoff                      |
| C22    | Unclear rồi turn hiểu được              | collecting            | fallback_count reset         |
| C23    | Map API error                           | operator_required     | handoff, không retry khách   |
| C24    | Khách yêu cầu operator                  | operator_required     | handoff ưu tiên cao          |
| C25    | Pickup đang di chuyển không resolve     | operator_required     | handoff sau làm rõ           |
| C26    | Cancel + confirm                        | canceled              | kết thúc                     |
| C27    | Cancel + deny                           | collecting/confirming | state cũ còn nguyên          |
| C28    | Repeat summary                          | unchanged             | không mutate state           |
| C29    | 4 chỗ → à thôi 7 chỗ                    | collecting            | giá trị cuối cùng            |
| C30    | Double confirm booking                  | booked                | chỉ 1 booking record         |
| C31    | Tool NOT_FOUND destination sau budget   | collecting/booked     | fallback vùng                |
| C32    | Optional được khách chủ động nêu        | collecting/booked     | extract nhưng không block    |

## 9.1. Format fixture đề xuất

> id: C13  
> initial_state: fixtures/state_after_greeting.json  
> turns:  
> - user: "Đón anh ở 12 Nguyễn Trãi, đổi sang xe 7 chỗ nhé, mà giá bao nhiêu một cây?"  
> mocks:  
> geocode: SUCCESS  
> kb_price_per_km: "..."  
> expect:  
> intents_contains: \[provide_info, change_info, ask_question\]  
> slots:  
> pickup.status: confirmed  
> vehicle_type.value: oto_7_cho  
> response_contains: \["giá", "điểm đến"\]  
> booking_status: collecting

# 10. Chiến lược kiểm thử theo tầng

| **Tầng**                | **Mục tiêu**                                          | **Ví dụ**                                                                       |
|-------------------------|-------------------------------------------------------|---------------------------------------------------------------------------------|
| Unit test               | Reducer/policy/ready_to_book không phụ thuộc LLM/API. | deny chỉ target slot; ready_to_book bỏ qua optional; priority request_operator. |
| Contract test           | Đảm bảo adapter trả schema đúng.                      | Map provider SUCCESS/NOT_FOUND/AMBIGUOUS/API_ERROR; CRM 0/1/2 địa chỉ.          |
| Conversation regression | Kiểm thử chuỗi nhiều turn và UX rule.                 | 32 case ở Mục 9.                                                                |
| Failure injection       | Chủ động timeout/500/malformed response.              | Map API error → handoff; không loop.                                            |
| Golden state test       | So state snapshot ở các mốc quan trọng.               | Sau sửa vehicle, pickup/destination/time không đổi.                             |
| Manual exploratory      | Tìm cách nói đời thường, viết tắt, sửa giữa câu.      | “4 chỗ à thôi 7”, “chỗ cũ”, “không nhớ”.                                        |

# 11. Kế hoạch triển khai theo milestone

[PHƯƠNG ÁN TRIỂN KHAI] Có thể triển khai theo 4 milestone. Thời lượng thực tế phụ thuộc số người và việc Map/LLM/CRM đã có sẵn; vì vậy tài liệu dùng deliverable và exit criteria thay vì gắn số ngày cứng.

| **Milestone**                                | **Phạm vi**                                                                           | **Exit criteria**                                                                      |
|----------------------------------------------|---------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|
| M0 - Skeleton & State                        | CLI loop, BotState, persistence đơn giản, mock providers, logging.                    | Có thể tạo session và chạy nhiều turn; state được lưu/đọc; chưa cần hiểu ngôn ngữ tốt. |
| M1 - Core booking dialogue                   | NLU structured extraction, reducer, 4 core slots, confirm/deny/change, ready_to_book. | Happy path + change/deny + multi-intent core pass; optional không block.               |
| M2 - Address intelligence & anti-frustration | Address resolver, alias/fuzzy, Mega POI, clarification budget, handoff rules.         | Toàn bộ TC-R02–R19 P0/P1 pass với mocks và ít nhất một provider thật.                  |
| M3 - FAQ/CRM/Booking & hardening             | RAG FAQ, CRM history, booking repo idempotency, failure injection, regression suite.  | 32 conversation tests pass; lỗi tool và double-confirm được kiểm soát.                 |

## 11.1. Backlog ưu tiên P0

- BotState + slot statuses + last_bot_action.target_slots.

- Ready-to-book derived state.

- Multi-intent extraction và reducer không mất entity.

- Confirm/deny/change_info cục bộ.

- Address rule tách pickup/destination.

- Destination fallback 1-2 lượt; Mega POI pickup 1 lượt.

- Fallback_count >=2 và API_ERROR → handoff.

- Request_operator priority cao nhất.

- Booking idempotency.

- Conversation regression harness.

## 11.2. Backlog P1/P2

- CRM “chỗ cũ/nhà/công ty”.

- Alias DB và fuzzy tuning.

- Landmark/giao cắt metadata.

- FAQ/RAG phong phú hơn.

- CLI debug view để QA xem slot/action sau mỗi turn.

- Repeat request/session question đầy đủ.

# 12. Logging và khả năng debug

[PHƯƠNG ÁN TRIỂN KHAI] Vì phần khó nhất của chatbot là “vì sao nó hỏi câu đó”, mỗi turn cần log dạng structured. Không log chain-of-thought; chỉ log dữ liệu nghiệp vụ phục vụ debug.

| **Field**                            | **Ý nghĩa**                                                 |
|--------------------------------------|-------------------------------------------------------------|
| session_id / turn_index              | Theo dõi luồng hội thoại.                                   |
| user_text                            | Input gốc (cần chính sách bảo mật phù hợp khi production).  |
| intents / extracted_slots            | Kết quả NLU có cấu trúc.                                    |
| slot_changes                         | Before → after cho từng slot.                               |
| tool_calls / tool_status             | Provider nào được gọi, kết quả loại gì, latency/error code. |
| last_bot_action / next_action        | Giải thích nghiệp vụ tại sao bot đang hỏi/xác nhận/handoff. |
| clarification_count / fallback_count | Phát hiện loop và rule chống ức chế.                        |
| booking_status / booking_id          | Theo dõi vòng đời cuốc.                                     |

> \# CLI debug mode (đề xuất)  
> USER\> Đón anh ở Times City  
> BOT \> Dạ khu vực này hơi rộng, anh đang gần tòa, cổng hoặc quán nào dễ thấy ạ?  
> DEBUG\> action=clarify_address target=\[pickup\]  
> DEBUG\> pickup.is_mega_poi=true clarification_count=1  
>   
> USER\> Anh không biết cổng nào  
> BOT \> Dạ, em sẽ dùng điểm đón mặc định tại Times City; tài xế sẽ chủ động gọi anh khi tới.  
> DEBUG\> pickup.status=confirmed default_point_used=true

# 13. Quy tắc sinh câu trả lời CLI

- Mỗi turn ưu tiên một mục tiêu chính: trả lời câu hỏi + hỏi đúng một phần còn thiếu nếu có thể.

- Không đọc lại toàn bộ booking sau mỗi slot; chỉ summary ở bước confirm_booking hoặc repeat_request.

- Khi fallback destination, nói rõ theo cách tự nhiên rằng sẽ lấy khu vực đó làm điểm đến; không tiếp tục gặng hỏi.

- Khi API lỗi, nói “hệ thống đang gặp lỗi định vị” thay vì “địa chỉ không hợp lệ”.

- Khi handoff trong CLI, kết thúc bằng thông báo rõ bot không tiếp tục tự động xử lý phiên này.

- Không hứa giá trọn gói; nếu được hỏi chỉ trả lời giá/km từ KB và nêu tiền cuối phụ thuộc đồng hồ/quãng đường thực tế.

# 14. Definition of Done cho MVP

**☐** Có thể khởi tạo session bằng phone + name; session_id là UUID riêng.

**☐** 4 slot core được lưu với value/status và address metadata cần thiết.

**☐** Intents là danh sách; một turn multi-intent không mất dữ liệu.

**☐** Confirm/deny/change_info hoạt động theo last_bot_action.target_slots.

**☐** Ready_to_book được tính từ state, không dùng cờ set tay phân tán.

**☐** Không hỏi optional nếu khách không nêu.

**☐** Pickup và destination có validation khác nhau đúng kiến trúc.

**☐** Destination không bị kẹt vì khách không biết số nhà/cổng.

**☐** Mega POI pickup không hỏi quá một lượt trước default fallback.

**☐** fallback_count >=2, API_ERROR, request_operator và pickup unsafe đều vào operator_required.

**☐** Booking create idempotent; không có double booking do retry/confirm lặp.

**☐** Tối thiểu 32 conversation regression tests ở Mục 9 pass.

**☐** P0 cases TC-R01–R16 và TC-R24 đều có test tự động.

**☐** CLI debug mode cho phép QA xem action/slot/status/counter mỗi turn.

**☐** Có README hướng dẫn chạy CLI, chạy tests và cấu hình provider mock/real.

# 15. Risk register và cách giảm thiểu

| **Rủi ro**                         | **Tác động**                                  | **Biện pháp MVP**                                                                                 |
|------------------------------------|-----------------------------------------------|---------------------------------------------------------------------------------------------------|
| LLM/NLU bỏ sót multi-intent        | Mất slot, khách phải nói lại                  | Structured schema + regression set câu nhiều ý + reducer không phụ thuộc primary_intent duy nhất. |
| Geocoder khác nhau theo môi trường | Test flakey, địa chỉ lúc được lúc không       | Mock contract deterministic cho CI; provider thật chỉ dùng smoke/integration test.                |
| Policy hỏi vòng lặp                | Khách bực, booking không hoàn thành           | Counter rõ cho clarification/fallback + invariant + test max-turn.                                |
| State bị reset khi deny/change     | Mất toàn bộ tiến trình                        | Immutable-ish reducer + snapshot tests trước/sau mỗi turn.                                        |
| Handoff không được ưu tiên         | Bot tiếp tục nói khi khách đã muốn người thật | Priority table cố định + unit test request_operator/cancel/tool error.                            |
| Double booking                     | Tạo hai cuốc                                  | Idempotency key theo session/booking lifecycle + repo unique guard.                               |
| FAQ trả lời lấn át giao dịch       | Bot quên booking                              | QA router chỉ trả answer; orchestration vẫn tiếp tục state machine.                               |

# 16. Output cần bàn giao sau MVP

- Mã nguồn CLI + domain logic + adapters.

- Schema BotState và booking entity có version.

- Local Alias DB ban đầu + danh sách Mega POI/default points dùng trong test.

- Conversation fixtures (ít nhất 32 case) và test report.

- Provider mocks cho Map/CRM/KB; cấu hình chuyển sang provider thật.

- README vận hành CLI và debug mode.

- Known limitations: các cách diễn đạt/time expression/chính sách chưa được đặc tả nghiệp vụ trong tài liệu này quy định rõ.

- Danh sách case production cần thu thập để mở rộng sau MVP.

# Phụ lục A - Bảng quyết định next action rút gọn

| **Điều kiện theo thứ tự ưu tiên**                          | **Next action**                                       |
|------------------------------------------------------------|-------------------------------------------------------|
| request_operator hoặc API_ERROR/pickup unsafe/fallback>=2 | human_handoff                                         |
| cancel xuất hiện và chưa xác nhận                          | confirm_cancel                                        |
| change_info/entity mới                                     | apply state update trước                              |
| confirm/deny                                               | apply lên last_bot_action.target_slots                |
| pickup needs_clarification                                 | clarify pickup theo safety/Mega POI rule              |
| destination needs_clarification                            | clarify trong budget; hết budget thì fallback confirm |
| ask_question                                               | answer_question, sau đó tiếp tục flow                 |
| 4 core slots confirmed                                     | confirm_booking/create booking                        |
| còn core slot empty                                        | ask_slot theo slot còn thiếu                          |
| chit_chat                                                  | general_reply ngắn rồi quay lại slot thiếu            |

# Phụ lục B - Mapping yêu cầu kiến trúc → hạng mục triển khai

| **Yêu cầu kiến trúc**                      | **Hạng mục trong kế hoạch**          |
|--------------------------------------------|--------------------------------------|
| 4 core slots + optional không gặng hỏi     | Mục 1, 5, 6, 7, TC-R01               |
| Multi-intent                               | Mục 4, TC-R08, C13                   |
| Confirm/deny/change_info theo target_slots | Mục 5, TC-R06/R07, C14/C15           |
| RAG/Tools/Session question                 | Module qa_router, TC-R09, C16/C17    |
| Pickup chính xác / destination linh hoạt   | Mục 6, TC-R02/R03/R12                |
| Alias/Fuzzy/Landmark/Intersection          | address_resolver, TC-R10/R11/R18/R19 |
| Mega POI 8A/8B                             | TC-R05, C07/C08                      |
| Human handoff 4 kịch bản                   | TC-R13–R16, C21/C23/C24/C25          |
| ready_to_book derived                      | Mục 5, M1, Definition of Done        |
| Rule priority                              | Mục 4, Phụ lục A                     |

> **Kết luận**  
> MVP được coi là thành công không chỉ khi “có thể tạo booking”, mà khi hệ thống chứng minh được ba thuộc tính: (1) không làm mất thông tin khách đã nói, (2) không gặng hỏi vượt quá giá trị cần thiết để tạo cuốc, và (3) biết dừng/handoff khi không thể xử lý an toàn. Bộ test regression phải bảo vệ ba thuộc tính này ở mọi lần thay đổi code.


---

# PHỤ LỤC C — Checklist onboarding cho thành viên mới

Sau khi đọc xong tài liệu, một thành viên mới cần trả lời được các câu sau trước khi bắt đầu sửa code:

- [ ] Bốn slot nào quyết định việc một cuốc có thể được tạo?
- [ ] Vì sao pickup không được dùng tọa độ trung tâm xã/phường, trong khi destination đôi lúc được phép?
- [ ] `extracted`, `confirmed` và `needs_clarification` khác nhau thế nào?
- [ ] Vì sao một turn phải dùng `intents[]` thay vì một `intent` duy nhất?
- [ ] `confirm` và `deny` dựa vào `last_bot_action.target_slots` như thế nào?
- [ ] Khi khách chỉ nói “không” sau một câu xác nhận nhiều slot, vì sao không được reset toàn bộ booking?
- [ ] Destination cấp xã/phường được hỏi tối đa bao nhiêu lượt và fallback ra sao?
- [ ] Mega POI pickup được hỏi làm rõ tối đa bao nhiêu lượt?
- [ ] Bốn nhóm điều kiện nào dẫn tới `human_handoff`?
- [ ] Vì sao `ready_to_book` phải là derived state?
- [ ] Vì sao `passengers`, `stopovers`, `general_note` không được block booking?
- [ ] Khi `ask_question` xuất hiện cùng `provide_info`, hệ thống phải giữ và xử lý cả hai như thế nào?
- [ ] Những test case P0 nào bảo vệ trực tiếp khỏi trải nghiệm gây ức chế?

Nếu chưa trả lời được các câu trên, nên đọc lại **Phần I**, **Mục 4–8 của Phần II** và **bộ TC-R01–TC-R24** trước khi thay đổi dialog policy hoặc state reducer.

---

# KẾT LUẬN

MVP không được đánh giá chỉ bằng việc bot “có thể tạo một booking”. Một bản MVP đạt yêu cầu phải đồng thời chứng minh được bốn năng lực:

1. **Hiểu và giữ dữ liệu khách đã cung cấp**, kể cả trong câu nhiều ý định.
2. **Hỏi tối thiểu nhưng đủ dùng**, với pickup chặt chẽ và destination linh hoạt hơn.
3. **Không mắc vòng lặp gây ức chế**, nhờ clarification budget, fallback rule và handoff rõ ràng.
4. **Có thể kiểm thử lặp lại**, với state assertion và conversation regression bảo vệ các hành vi quan trọng.

File này là tài liệu nền để Product chốt hành vi, Dev triển khai và QA nghiệm thu MVP Text CLI.
