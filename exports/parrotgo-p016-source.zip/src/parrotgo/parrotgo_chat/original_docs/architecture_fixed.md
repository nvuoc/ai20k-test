# KIẾN TRÚC HỆ THỐNG CHATBOT ĐẶT XE TỔNG ĐÀI (GIAI ĐOẠN MVP - TEXT CLI)

## 1. Phạm vi MVP, khởi tạo phiên & tương tác cơ bản

### 1.1. Phạm vi MVP

* MVP hiện tại chạy ở **Text CLI**. Người dùng nhập nội dung dạng text; các thành phần Voice như Caller ID, Speech-to-Text (STT), chuyển line tổng đài chỉ được xem là **adapter/giai đoạn mở rộng**, không phải phụ thuộc bắt buộc của MVP.
* Logic nghiệp vụ cốt lõi (intent, slot filling, geocoding, RAG, xác nhận, hủy cuốc) phải độc lập với kênh giao tiếp để sau này có thể tái sử dụng cho Voicebot.

### 1.2. Khởi tạo phiên (Session)

* Khách hàng nhập **Số điện thoại** và **Tên** để bắt đầu phiên MVP.
* `session_id` là một UUID riêng cho từng cuộc hội thoại/phiên đặt xe; **không dùng SĐT làm Session ID**.
* `customer_phone` là khóa nhận diện khách hàng để truy vấn CRM/lịch sử. Một số điện thoại có thể có nhiều `session_id` khác nhau theo thời gian.
* Toàn bộ message, slot và action của phiên được lưu theo `session_id`.

### 1.3. Cơ chế báo giá

* Tổng đài không tính tiền trọn gói từ trước.
* Bot chỉ báo **giá tiền trên mỗi KM** (thông tin lấy từ RAG/Knowledge Base).
* Số tiền cuối cùng phụ thuộc vào đồng hồ tính tiền/quãng đường thực tế tài xế đi.

### 1.4. Cá nhân hóa từ lịch sử

* Hệ thống dùng `customer_phone` truy vấn CRM để lấy các địa chỉ quen thuộc, ví dụ: *"Có phải đón anh ở công ty như mọi khi không?"*.
* Ở Voice phase, `customer_phone` có thể lấy từ Caller ID. Ở MVP Text CLI, số điện thoại do người dùng nhập khi khởi tạo phiên.

---

## 2. Data Model (Thực thể Cuốc Xe - Booking Entity)

Một cuốc xe hoàn chỉnh lưu vào Database gồm:

### 2.1. Thông tin định danh

* Mã ID cuốc xe (`booking_id`)
* `session_id`
* Tên khách hàng
* Số điện thoại

### 2.2. Thông tin bắt buộc

* Điểm đón (Pickup)
* Điểm đến (Destination)
* Thời gian đón (Pickup Time)
* Loại xe (Vehicle Type: xe máy, ô tô 4 chỗ, ô tô 7 chỗ)

### 2.3. Thông tin bổ sung

* Điểm dừng (Stopovers - nếu khách muốn đi nhiều điểm)
* Số hành khách (Passengers)
* Ghi chú chung (Notes - ví dụ: *"cốp rộng"*, *"tài xế không hút thuốc"*)

### 2.4. Thông tin hệ thống tự tính toán

* Quãng đường ước tính (Distance)
* Tọa độ đã chuẩn hóa của pickup, destination và các stopover
* Cờ Mega POI và thông tin default pickup/drop-off nếu có

### 2.5. Trạng thái của từng slot

Mỗi slot quan trọng không chỉ có `value`, mà cần có trạng thái để phân biệt dữ liệu mới bóc tách với dữ liệu đã được khách xác nhận.

Các trạng thái đề xuất:

* `empty`: chưa có dữ liệu
* `extracted`: đã bóc tách nhưng chưa xác nhận
* `confirmed`: khách đã xác nhận
* `needs_clarification`: dữ liệu chưa đủ rõ/cần hỏi lại

Điều này giúp xử lý đúng các intent `confirm`, `deny`, `change_info` mà không phải xóa dữ liệu một cách mù quáng.

---

## 3. Phân loại Ý định (Intents)

### 3.1. Nguyên tắc Multi-intent

Mỗi câu nói/lời nhập của khách hàng có thể chứa **một hoặc nhiều ý định**. Vì vậy hệ thống phải lưu danh sách `intents`, không dùng một biến `intent` đơn lẻ.

Ví dụ:

> "Đón anh ở 12 Nguyễn Trãi, đổi sang xe 7 chỗ nhé, mà giá bao nhiêu một cây?"

Có thể đồng thời chứa:

* `provide_info` → pickup = "12 Nguyễn Trãi"
* `change_info` → vehicle_type = "oto_7_cho"
* `ask_question` → hỏi giá/km

### 3.2. Nhóm Giao dịch (Transactional)

* `provide_info`: Cung cấp thông tin mới; bóc tách chính xác entity/slot.
  * Ví dụ: *"Cho xe 4 chỗ, à thôi 7 chỗ đi"* → giá trị cuối cùng của `vehicle_type` là `oto_7_cho`.

* `change_info`: Thay đổi thông tin đã có; cập nhật đè đúng slot được nhắc tới và chuyển trạng thái slot đó về `extracted` hoặc `needs_clarification` tùy dữ liệu mới.

* `confirm`: Xác nhận slot/action bot vừa hỏi.
  * Không dùng một cờ `True` chung.
  * Chỉ chuyển các slot nằm trong `last_bot_action.target_slots` sang `confirmed`.

* `deny`: Từ chối thông tin bot vừa hỏi.
  * Nếu khách chỉ rõ slot sai → chỉ invalidate/xóa slot đó.
  * Nếu bot đang xác nhận nhiều slot và khách nói rõ giá trị thay thế → cập nhật đúng slot được sửa, **không xóa các slot còn lại**.
  * Nếu bot đang xác nhận nhiều slot nhưng khách chỉ nói *"không"* mà không chỉ rõ slot nào sai → không xóa toàn bộ; hỏi ngắn gọn slot nào cần sửa.

* `cancel`: Hủy cuốc.
  * Bot hỏi xác nhận hủy.
  * Nếu khách `confirm` → kết thúc phiên đặt xe với trạng thái canceled.
  * Nếu khách `deny` → quay lại tiến trình thu thập/xác nhận thông tin còn thiếu.

* `repeat_request`: Yêu cầu nói/hiển thị lại.
  * Có thể đọc lại slot cụ thể hoặc tóm tắt toàn bộ cuốc xe.

### 3.3. Nhóm Hỏi - Đáp

* `ask_question`: Câu hỏi cần trả lời bằng RAG, Tool/API hoặc Session Management (xem mục 4).
* `chit_chat`: Bot trả lời ngắn gọn, tự nhiên rồi quay lại mục tiêu hoàn thiện cuốc xe.

### 3.4. Nhóm Xử lý lỗi

* `unclear`: Không hiểu ý chính của khách.
  * Nếu câu vẫn chứa entity hợp lệ thì **vẫn cập nhật entity đó**.
  * Sau đó bot hỏi lại phần còn thiếu hoặc phần đang cần làm rõ.

### 3.5. Thứ tự xử lý một turn có nhiều intent

Để tránh mất dữ liệu, một turn nên được xử lý theo nguyên tắc:

1. Bóc tách toàn bộ entity/slot từ câu khách.
2. Áp dụng `change_info`/giá trị sửa cuối cùng trước khi ghi state.
3. Xử lý `confirm`/`deny` dựa trên `last_bot_action`.
4. Trả lời `ask_question` nếu có.
5. Xử lý `cancel` nếu xuất hiện và cần xác nhận hủy.
6. Sau cùng mới quyết định câu hỏi tiếp theo cho slot còn thiếu/chưa rõ.

---

## 4. Luồng Hỏi - Đáp (RAG & Tools)

Phân loại câu hỏi của khách để điều hướng xử lý:

### Nhóm 1: Static FAQ → RAG / Knowledge Base

Các thông tin tương đối ổn định:

* Sức chứa hành lý
* Thú cưng
* Đồ cồng kềnh
* Ghế trẻ em
* Quy định hút thuốc
* Giá trên km
* Chính sách dịch vụ khác

### Nhóm 2: Dynamic API → Function Calling / Tools

Các thông tin phụ thuộc thời gian/không gian:

* Quãng đường ước tính
* Thời gian đi dự kiến
* Thời tiết
* Geocoding địa chỉ
* Kiểm tra một điểm có nằm trên/gần lộ trình không
* Tìm POI, ngã tư, cổng/sảnh, default pickup/drop-off

### Nhóm 3: Session Management

Các câu hỏi dựa trên state hiện tại, ví dụ:

* *"Nãy tôi đặt đi đâu nhỉ?"*
* *"Tôi đã chọn xe gì rồi?"*
* *"Đọc lại giúp tôi thông tin chuyến đi."*

### Quy tắc khi câu hỏi xuất hiện cùng dữ liệu đặt xe

Bot phải vừa trả lời câu hỏi, vừa giữ/cập nhật các slot hợp lệ trong cùng turn. Không được vì `ask_question` mà bỏ qua `provide_info` hoặc `change_info`.

---

## 5. Xử lý địa chỉ và định vị

### 5.1. Nguyên tắc chung

* **Điểm đón (Pickup)** phải đủ chính xác để tài xế có thể tìm khách hoặc phải có cơ chế fallback rõ ràng.
* **Điểm đến (Destination)** có thể chấp nhận mức chi tiết thấp hơn pickup trong một số trường hợp (đặc biệt Mega POI), vì tài xế có thể hỏi khách khi đang di chuyển.
* **Stopover** phải được geocode thành cấu trúc địa chỉ đầy đủ như pickup/destination, không chỉ lưu chuỗi text.
* Không dùng tọa độ trung tâm của một vùng/đường quá rộng làm pickup nếu điều đó không giúp tài xế tìm được khách.

### Trường hợp 1: Khách cung cấp thông tin cấp vùng rộng (Tỉnh/Thành phố/Quận/Huyện/Xã/Phường)

* **Đặc điểm:** Khách nói *"Cho tôi một xe ở Hà Nội"* hoặc *"Đón ở phường Thanh Xuân Trung"*.
* **Xử lý:** Không dùng tọa độ trung tâm hành chính làm pickup. Bot hỏi thẳng thông tin chi tiết hơn:
  * *"Dạ, anh/chị đang ở đường nào hoặc tòa nhà/địa điểm nào thuộc Thanh Xuân Trung ạ?"*

### Trường hợp 2: Khách cung cấp tên Đường/Phố/Thôn nhưng thiếu số nhà

* **Đặc điểm:** *"Đón ở đường Nguyễn Trãi"*, *"Cho xe đến thôn Phú Mỹ"*.
* Gửi chuỗi địa chỉ cho Map API kèm Location Biasing theo khu vực hoạt động.
* Nếu có nhiều kết quả trùng tên → hỏi trắc nghiệm để loại trừ.
* Nếu kết quả duy nhất:
  * Với **pickup**: không tự chốt tọa độ trung tâm cả tuyến đường. Hỏi thêm số nhà/ngõ/landmark hoặc vị trí cụ thể dễ tìm.
  * Với **destination**: có thể chấp nhận địa điểm tổng quát hơn nếu đủ để điều hướng; nếu quá rộng thì hỏi thêm một lần hoặc dùng điểm đại diện hợp lý tùy loại địa điểm.

### Trường hợp 3: Khách cung cấp Số nhà/Ngõ/Ngách + Tên đường

* **Đặc điểm:** *"12 Nguyễn Trãi"*, *"Ngõ 55 Khương Trung"*.
* Không cần hỏi ngược lại xã/phường nếu Map API đã resolve duy nhất với độ tin cậy đủ cao.
* Bot đọc lại địa chỉ chuẩn hóa để xác nhận trước khi chuyển slot sang `confirmed`.

### Trường hợp 4: Khách gọi tên địa danh bằng từ lóng/phiên âm/tên quen dùng

* **Đặc điểm:** Ocean Park 1, Vi Na Côn, Kengnam, Sân bay Nội Bài, Lăng Bác...
* Xây dựng **Local Alias DB** (từ đồng nghĩa, cách gọi quen, lỗi STT thường gặp).
* Thứ tự đề xuất:
  1. Tra Local Alias DB.
  2. Nếu match chắc chắn → lấy tên chuẩn + tọa độ/POI metadata.
  3. Nếu không match → gọi Map API/Fuzzy Search.
* Với MVP Text CLI, cơ chế này xử lý alias và lỗi gõ. Với Voice phase, bổ sung alias phát âm/STT.

### Trường hợp 5: Khách cung cấp Điểm Neo / Điểm mốc (Landmark-based routing)

* **Đặc điểm:** *"Đối diện bảo tàng Phòng không Không quân"*, *"Bên trái trường tiểu học Minh Khai"*.
* NLP nhận diện từ chỉ hướng như `đối diện`, `bên trái`, `cổng sau`.
* Geocode **Điểm Neo**, không tạo tọa độ ảo cho vị trí đối diện/bên trái.
* Lưu phần chỉ hướng vào `note` để tài xế đọc được:
  * `Đón khách ở [từ chỉ hướng] + [điểm neo]`.

### Trường hợp 6: Khách gọi xe theo thói quen / lịch sử cá nhân

* **Đặc điểm:** *"Cho chị một xe đến chỗ cũ nhé"*, *"Đón ở nhà nha em"*, *"Qua công ty anh lấy đồ"*.
* Dùng `customer_phone` truy vấn CRM, lấy 1-2 địa chỉ phù hợp nhất.
* Bot hỏi xác nhận địa chỉ gợi ý.
* Nếu khách từ chối → quay về luồng hỏi địa chỉ bình thường, không xóa các slot khác.

### Trường hợp 7: Khách đứng tại điểm giao cắt (Ngã ba, Ngã tư)

* **Đặc điểm:** *"Đón ở ngã tư Sở"*, *"Ngã tư Khuất Duy Tiến giao Lê Văn Lương"*.
* Nhận diện từ khóa `ngã ba`, `ngã tư`, `giao với`.
* Query cụm giao cắt vào Map API.
* Nếu resolve duy nhất, có thể dùng làm pickup và thêm ghi chú để tài xế chủ động gọi khách khi tới giao lộ.

### Trường hợp 8: Mega POI - quy tắc thống nhất

Mega POI là khu vực lớn có nhiều cổng/sảnh/tòa, ví dụ Times City, Ocean Park, bệnh viện lớn, sân bay.

Khi geocoding/Local DB xác định địa điểm là Mega POI, lưu `is_mega_poi = true` và metadata liên quan trong chính slot địa chỉ để các turn sau vẫn biết trạng thái này.

#### 8A. Mega POI là Điểm đến (Destination)

* Không ép khách cung cấp tòa/cổng cụ thể nếu họ không biết hoặc không muốn nói.
* Có thể chốt bằng `default_dropoff_point`/main gate/điểm đại diện đã cấu hình trong Local DB.
* Lưu `default_point_used = true` nếu dùng điểm mặc định.
* Tài xế có thể hỏi khách chi tiết khi gần tới nơi.

#### 8B. Mega POI là Điểm đón (Pickup)

Ưu tiên tìm vị trí cụ thể nhưng **không hỏi dồn**.

1. Nếu khách đã cung cấp sub-location rõ (cổng, sảnh, tòa, quán/điểm mốc) → geocode và xác nhận.
2. Nếu chưa rõ → bot chỉ hỏi **một lượt** câu hỏi hẹp/mở phù hợp, ví dụ:
   * *"Dạ khu vực này hơi rộng, anh/chị đang gần tòa, cổng hoặc quán nào dễ thấy để tài xế tìm mình ạ?"*
3. Nếu khách cung cấp được → cập nhật pickup và xác nhận.
4. Nếu khách không biết, từ chối trả lời hoặc tỏ ra khó chịu → dừng hỏi ngay.
5. Dùng `default_pickup_point` đã cấu hình sẵn cho Mega POI.
6. Gắn `default_point_used = true` và thêm cảnh báo/ghi chú để tài xế chủ động gọi khách.

> Quy tắc 8B **ghi đè** mọi rule chung kiểu “Mega POI bắt buộc phải hỏi đến khi có vị trí hẹp”. Pickup Mega POI chỉ được hỏi làm rõ tối đa một lượt trước khi fallback sang default pickup.

### Trường hợp 9: Khách đang di chuyển hoặc không xác định được vị trí

* **Đặc điểm:** *"Anh đang đi bộ dọc đường hướng về Hà Đông"*, *"Chị không rõ đây là đâu, thấy trước mặt có cây xăng"*.
* Không hỏi dồn nhiều lượt.
* Nếu có landmark đủ dùng → thử xử lý theo Trường hợp 5.
* Nếu vẫn không thể xác định pickup đủ an toàn:
  * MVP Text CLI: chuyển trạng thái `human_handoff`/`operator_required` và thông báo cần nhân viên hỗ trợ.
  * Voice phase: thực hiện chuyển line cho tổng đài viên.

### Trường hợp 10: Khách gõ sai/phát âm sai/nói ngọng/nhớ nhầm tên đường

* Dùng Fuzzy Search dựa trên khoảng cách chuỗi; Voice phase có thể bổ sung độ tương đồng ngữ âm và lỗi STT.
* Nếu có candidate xác suất cao nhưng không chắc chắn tuyệt đối → đọc/hiển thị tên chuẩn để khách xác nhận.
* Không tự động ghi `confirmed` chỉ vì fuzzy match có điểm cao.

---

## 6. Thiết kế BotState

```python
from typing import Any, Dict, List, Literal, Optional
from typing_extensions import TypedDict


Intent = Literal[
    "provide_info",
    "confirm",
    "deny",
    "ask_question",
    "change_info",
    "cancel",
    "chit_chat",
    "unclear",
    "repeat_request",
]

SlotStatus = Literal[
    "empty",
    "extracted",
    "confirmed",
    "needs_clarification",
]


class Coordinates(TypedDict):
    lat: float
    lng: float


class AddressComponents(TypedDict, total=False):
    detail: Optional[str]
    street: Optional[str]
    ward: Optional[str]
    district: Optional[str]
    province_city: Optional[str]


class AddressSlot(TypedDict):
    raw: Optional[str]
    formatted: Optional[str]
    coords: Optional[Coordinates]
    components: Optional[AddressComponents]

    # Thông tin tìm khách / landmark
    note: Optional[str]

    # Mega POI
    is_mega_poi: bool
    default_point_used: bool

    # Trạng thái slot
    status: SlotStatus


class StopoverSlot(TypedDict):
    address: AddressSlot
    order: int


class ValueSlot(TypedDict):
    value: Any
    status: SlotStatus


class RouteResult(TypedDict):
    success: bool
    distance_km: Optional[float]
    duration_minutes: Optional[float]
    waypoints_count: int


class BookingSlots(TypedDict):
    # Địa chỉ
    pickup: AddressSlot
    destination: AddressSlot
    stopovers: List[StopoverSlot]

    # Thời gian & loại xe
    pickup_time: ValueSlot
    vehicle_type: ValueSlot  # value: "xe_may" | "oto_4_cho" | "oto_7_cho"
    passengers: ValueSlot

    # Ghi chú chung
    general_note: Optional[str]

    # Dữ liệu hành trình
    distance_km: Optional[float]
    duration_minutes: Optional[float]


class ExtractedSlotUpdate(TypedDict):
    slot_name: str
    value: Any
    source_text: str


class BotAction(TypedDict):
    action_type: Literal[
        "ask_slot",
        "confirm_slots",
        "confirm_booking",
        "clarify_address",
        "answer_question",
        "inform_success",
        "general_reply",
        "confirm_cancel",
        "human_handoff",
    ]

    # Có thể tác động/xác nhận nhiều slot trong một lượt.
    target_slots: List[str]
    metadata: Optional[Dict[str, Any]]


class BotState(TypedDict):
    # Phiên & khách hàng
    session_id: str                 # UUID riêng cho từng phiên
    customer_phone: str             # Khóa tra CRM, không phải Session ID
    customer_name: str              # Bắt buộc ở MVP theo luồng khởi tạo
    messages: List[Dict[str, str]]

    # Trạng thái nghiệp vụ
    booking_slots: BookingSlots
    turn_extracted_slots: List[ExtractedSlotUpdate]

    # Multi-intent: một turn có thể chứa nhiều intent
    intents: List[Intent]
    primary_intent: Optional[Intent]

    # Điều phối
    current_focus: Optional[str]
    last_bot_action: Optional[BotAction]
    tool_status: Optional[
        Literal["SUCCESS", "NOT_FOUND", "AMBIGUOUS", "API_ERROR"]
    ]
    fallback_count: int

    # Trạng thái vòng đời booking
    booking_status: Literal[
        "collecting",
        "confirming",
        "ready_to_book",
        "booked",
        "cancel_pending",
        "canceled",
        "operator_required",
    ]

    final_response_text: Optional[str]
```

---

## 7. Quy tắc xác định `ready_to_book`

Không nên duy trì `is_ready_to_book` như một cờ được set tùy ý ở nhiều nơi. Nên **tính ra (derived state)** từ dữ liệu hiện tại để tránh state lệch.

Một booking được coi là `ready_to_book` khi:

* `pickup.status == "confirmed"`
* `destination.status == "confirmed"`
* `pickup_time.status == "confirmed"`
* `vehicle_type.status == "confirmed"`
* Không có địa chỉ bắt buộc nào ở trạng thái `needs_clarification`
* Nếu pickup dùng Mega POI default point thì `default_point_used == true` và đã có note/cảnh báo cần thiết cho tài xế

`passengers`, `stopovers`, `general_note` là tùy chọn trừ khi nghiệp vụ thực tế yêu cầu khác.

---

## 8. Nguyên tắc ưu tiên khi các rule cùng match

Khi một câu có thể rơi vào nhiều rule, áp dụng theo thứ tự ưu tiên sau:

1. `cancel` / xác nhận hủy
2. `change_info` và entity mới trong turn
3. `confirm` / `deny` gắn với `last_bot_action`
4. Rule an toàn/khả năng tìm khách của pickup
5. Rule Mega POI (8A/8B)
6. Geocoding/Fuzzy/Local Alias DB
7. `ask_question` (RAG/Tools/Session)
8. `chit_chat`
9. Hỏi slot còn thiếu tiếp theo

Mục tiêu của thứ tự này là **không làm mất entity hợp lệ**, không xóa nhầm slot, và không để một intent phụ khiến bot bỏ qua thay đổi nghiệp vụ quan trọng trong cùng turn.
