# Triển khai architecture_fixed.md

Kiến trúc hiện hành là `architecture-fixed-1`, state schema 7. HTTP, `app.text.main`, `TextBot` và CLI dùng cùng `domain.booking_engine.ConversationEngine`; kênh giao tiếp không quyết định nghiệp vụ.

| Yêu cầu | Mã nguồn thực thi |
| --- | --- |
| Tên/SĐT bắt buộc; UUID riêng; SĐT là khóa CRM | `contracts/booking.py`, `contracts/chat.py`, `main.py`, `text.py`, `adapters/crm_sqlite.py` |
| BotState, AddressSlot, StopoverSlot, bốn trạng thái slot | `contracts/booking.py` |
| Multi-intent, giữ entity hợp lệ, sửa trước xác nhận, xác nhận theo phạm vi, phủ nhận có chọn lọc | `domain/booking_engine.py`, `contracts/turn.py`, `prompts/turn_v2.txt` |
| Hủy có bước xác nhận; từ chối hủy thì tiếp tục | `domain/booking_engine.py`, action `confirm_cancel` trong `contracts/chat.py` |
| Giá/km và FAQ từ KB; không tính tổng tiền chuyến | `adapters/knowledge_base.py`, `fixtures/knowledge_base.json` |
| Bản đồ, thời tiết, tuyến, khoảng cách, thời gian | `domain/inquiries.py`, các map/weather adapters |
| Kiểm tra điểm gần tuyến | `_route_membership` trong `domain/booking_engine.py`: so sánh lộ trình qua điểm bằng bản đồ, ghi rõ đây là ước tính đi vòng; không giả định có dữ liệu hình học tuyến |
| Alias/fuzzy, vùng rộng, landmark, giao lộ | `domain/local_aliases.py`, `location_parser.py`, `domain/booking_engine.py` |
| Mega POI hỏi pickup tối đa một lượt, default có nguồn, note tài xế gọi khách | `domain/mega_poi.py`, `fixtures/mega_pois.json`, `domain/booking_engine.py` |
| Readiness được suy ra từ bốn slot bắt buộc; hành khách tùy chọn | `contracts/booking.py::ready_to_book` |
| Stopover có địa chỉ/tọa độ, lộ trình bao gồm mọi chặng | `domain/booking_engine.py::_resolve_addresses`, `_route` |
| Lưu message/slot/action theo UUID, inbox và phục hồi giao dịch | `api_store.py`, `graph/builder.py`, `workers/coordinator.py`, `adapters/booking_sandbox.py` |

`booking_slots` là dữ liệu nghiệp vụ gốc. `booking_state` và `resolution` là projection cho NLU/tra cứu và adapter cũ, không phải reducer thứ hai. Các giao dịch chưa rõ kết quả lưu tại `transaction.active_operation.status`; không tạo/hủy thêm trong lúc đối soát.

Luồng đặt: nhập hồ sơ → thu thập/geocode → xác nhận địa chỉ và các slot còn lại theo `last_bot_action.target_slots` → tóm tắt với đơn giá/km → xác nhận tạo cuốc. Luồng hủy: yêu cầu hủy → `cancel_pending` → xác nhận riêng → `canceled`. Readiness không thay cho đồng ý tạo cuốc.

Phiên cũ giữ nguyên ID, ledger và thông tin giao dịch. Consent cũ không được dùng để đặt theo chính sách mới. Phiên thiếu hồ sơ yêu cầu mở phiên mới có tên/SĐT; dữ liệu cũ vẫn được lưu để kiểm tra. `LegacyConversationEngine`, reducer/quote/gói hỗ trợ V1–V3 được giữ cho kiểm thử tương thích lịch sử và không được chọn trong runtime hiện hành.

`KNOWLEDGE_BASE_PATH` cấu hình KB JSON có version, policies và ba loại xe với `per_km`. `MEGA_POI_PATH` cấu hình alias và truy vấn default pickup/drop-off; map adapter phải resolve trước khi dùng tọa độ. `LOCAL_ALIAS_PATH` và `SERVICE_AREA_PATH` vẫn cấu hình nguồn địa điểm. Các flags tự chốt địa điểm/phí hỗ trợ V3 không bật hành vi đó trong lõi mới.

Các địa điểm, tuyến, đơn giá và chính sách đi kèm là dữ liệu sandbox. Tạo/hủy cuốc vẫn dùng provider sandbox, chưa điều phối tài xế. `operator_required` là trạng thái chờ hỗ trợ, chưa tự gửi thông báo cho nhân viên. Registry/KB vận hành phải được cấu hình trước khi phục vụ khách thật.

Kiểm thử kiến trúc nằm tại `src/backend/tests/test_architecture_fixed.py`; API kiểm tra hồ sơ, ACK, tham chiếu, đặt/hủy, persistence và idempotency. Browser E2E kiểm tra nhập hồ sơ, xác nhận qua văn bản, tải lại phiên, Mega POI, inquiry, weather và mobile. Các kiểm thử V1–V3 gọi rõ `LegacyConversationEngine` để phân biệt với các kiểm thử của lõi hiện hành.
