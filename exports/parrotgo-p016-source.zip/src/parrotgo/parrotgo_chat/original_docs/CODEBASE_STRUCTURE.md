# Cấu Trúc Cây Mã Nguồn Repo ParrotGo (P-016)

Tài liệu này mô tả chi tiết toàn bộ cấu trúc thư mục, các tệp tin và trách nhiệm kiến trúc của repository **ParrotGo (P-016)** — Hệ thống Voice AI hỗ trợ đặt xe thông minh bằng tiếng Việt.

---

## 1. Sơ Đồ Cây Thư Mục Tổng Quan

```text
P-016/
├── .agents/                      # Cấu hình workflow, hook và quy tắc AI
├── .ai-log/                      # Nhật ký hoạt động tương tác AI (session/archive)
├── .speech-output/               # Tệp âm thanh mẫu / kết quả tổng hợp TTS
├── core/                         # [Tương thích] Alias trỏ đến Speech Core adapter
├── data/                         # Cơ sở dữ liệu SQLite cục bộ (rides.db)
├── docs/                         # Tài liệu kỹ thuật, đặc tả kiến trúc & tài liệu hướng dẫn
├── eval/                         # Kịch bản và kết quả đánh giá (Benchmark STT, LLM, Tool)
├── frontend/                     # Giao diện Web demo (HTML, CSS, JavaScript, WebRTC)
├── livekit_server/               # Cấu hình máy chủ LiveKit SFU (WebRTC)
├── presentation/                 # Tài liệu thuyết trình và demo dự án
├── scripts/                      # Bộ script kiểm thử âm thanh, benchmark và AI logging
├── speech/                       # [Tương thích] Alias trỏ đến src/modules/speech
├── src/                          # Mã nguồn chính của ứng dụng
│   ├── agents/                   # [Tương thích] Wrapper cũ của Core & Tools
│   ├── api/                      # Định nghĩa HTTP REST API (FastAPI)
│   ├── domain/                   # Các thực thể nghiệp vụ và quy tắc cốt lõi
│   ├── models/                   # Pydantic schemas dùng chung cho HTTP/Tools
│   ├── modules/                  # 4 Module cốt lõi: Core, LLM, Tool, Speech
│   │   ├── core/                 # LangGraph State Machine điều phối hội thoại
│   │   ├── llm/                  # Trích xuất thực thể và lập kế hoạch câu thoại
│   │   ├── speech/               # Xử lý STT, TTS, VAD và kết nối LiveKit
│   │   └── tool/                 # Bộ công cụ nghiệp vụ: Map, Fare, Booking
│   ├── parrotgo/                 # Tài liệu đặc tả kỹ thuật MVP và kế hoạch CLI
│   ├── services/                 # Tầng dịch vụ hạ tầng (DB, Geocoding, Dispatch, LiveKit)
│   ├── config.py                 # Quản lý cấu hình tập trung (Pydantic Settings)
│   └── main.py                   # Điểm khởi chạy ứng dụng FastAPI
├── tests/                        # Hệ thống kiểm thử tự động (Unit, Contract, Integration)
├── worker/                       # [Tương thích] LiveKit worker tiến trình phụ
├── .dockerignore
├── .env.example                  # Mẫu biến môi trường
├── .gitattributes
├── .gitignore
├── ARCHITECTURE.md               # Đặc tả kiến trúc tổng thể toàn hệ thống
├── architecture_diagram.md       # Sơ đồ kiến trúc chi tiết (Mermaid)
├── CODE_OF_CONDUCT.md
├── CONTRIBUTING.md
├── docker-compose.yml            # Khởi chạy LiveKit Server và Backend
├── Dockerfile                    # Containerization cho ứng dụng
├── IMPLEMENTATION_PLAN.md        # Kế hoạch triển khai kỹ thuật
├── JOURNAL.md                    # Nhật ký phát triển
├── LICENSE
├── Makefile                      # Lệnh tự động hóa (test, lint, run)
├── README.md                     # Hướng dẫn cài đặt, thiết lập và sử dụng
├── requirements.txt              # Danh sách thư viện Python phụ thuộc
├── ruff.toml                     # Cấu hình linter Ruff
├── run_mvp.py                    # Entrypoint chạy thử nghiệm nhanh bản MVP
├── SECURITY.md
└── WORKLOG.md
```

---

## 2. Chi Tiết Các Tầng Mã Nguồn Trong `src/`

Thư mục `src/` chứa toàn bộ logic ứng dụng, được tổ chức theo kiến trúc module hóa kết hợp Domain-Driven Design (DDD):

```text
src/
├── config.py                     # Quản lý cấu hình & biến môi trường
├── main.py                       # Khởi tạo FastAPI app, middleware, routes
│
├── api/                          # Tầng tiếp nhận yêu cầu HTTP
│   ├── routes.py                 # Endpoint text chat (/api/v1/chat), status, rides
│   └── voice_routes.py           # Endpoint voice turn (/api/v1/voice-turn), token LiveKit
│
├── domain/                       # Thực thể nghiệp vụ (Domain Entities & Value Objects)
│   ├── address.py                # Mô hình địa chỉ, chuẩn hóa tọa độ và vị trí
│   ├── booking.py                # Trạng thái đặt xe (DRAFT, CONFIRMED, DISPATCHED, CANCELLED)
│   ├── conversation.py           # Quản lý phiên hội thoại, lịch sử tin nhắn
│   └── pricing.py                # Bảng giá theo loại xe (xe_may, oto_4_cho, oto_7_cho)
│
├── models/
│   └── schemas.py                # Request/Response DTOs cho API và Tools
│
├── modules/                      # 4 KHỐI MODULE CỐT LÕI
│   ├── core/                     # --- Module 1: Quản lý Hội thoại (Core Orchestration) ---
│   │   ├── api.py                # Hàm entrypoint `core_func(user_text, session_id)`
│   │   ├── graph.py              # Định nghĩa LangGraph StateGraph (`build_graph`)
│   │   ├── state.py              # Schema trạng thái hội thoại (`CoreState`, slots, locks)
│   │   ├── adapters/             # Cầu nối tích hợp giữa Core với LLM và Tool
│   │   │   ├── llm.py            # Adapter gọi LLM Extractor & Planner
│   │   │   ├── tool_backend.py   # Adapter thực thi Tool với cơ chế khóa nghiệp vụ
│   │   │   └── tools.py          # Helper tích hợp danh sách tool vào node
│   │   ├── nodes/                # Các Node xử lý trong đồ thị LangGraph:
│   │   │   ├── context.py        # Chuẩn bị ngữ cảnh và lịch sử hội thoại
│   │   │   ├── extractor.py      # Gọi LLM Extractor để bóc tách ý định & thực thể
│   │   │   ├── validation.py     # Kiểm tra 5 thông tin bắt buộc và tính hợp lệ địa chỉ
│   │   │   ├── state_manager.py  # Cập nhật và chuyển dịch trạng thái hội thoại
│   │   │   ├── booking.py        # Xử lý bước đặt xe, gọi Map/Fare/Booking tools
│   │   │   ├── cancellation.py   # Xử lý yêu cầu hủy chuyến của khách
│   │   │   └── response.py       # Tổng hợp câu phản hồi cho người dùng qua Planner
│   │   └── policies/             # Chính sách nghiệp vụ bảo vệ luồng:
│   │       ├── booking.py        # Điều kiện khóa đơn và điều phối xe
│   │       ├── confirmation.py   # Quy tắc bắt buộc khách xác nhận trước khi book
│   │       └── slots.py          # Quản lý 5 slots: pickup, dropoff, time, passengers, vehicle
│   │
│   ├── llm/                      # --- Module 2: Trí tuệ Nhân tạo & Structured Outputs ---
│   │   ├── api.py                # Giao diện công khai: `llm_extractor_func`, `llm_planner_func`
│   │   ├── extractor.py          # Trích xuất 5 trường thông tin theo JSON schema nghiêm ngặt
│   │   ├── planner.py            # Lên kế hoạch phản hồi, quyết định gọi tool hoặc hỏi thêm
│   │   ├── provider.py           # Client kết nối nhà cung cấp LLM (OpenAI-compatible)
│   │   ├── schemas.py            # Pydantic schema cho Structured Outputs
│   │   ├── templates.py          # Prompt templates tiếng Việt chuẩn hóa
│   │   ├── config.py             # Cấu hình model, nhiệt độ (temperature), deadline timeout
│   │   ├── result.py             # Kiểu dữ liệu trả về chuẩn hóa
│   │   └── _json.py              # Helper parse và sửa lỗi JSON
│   │
│   ├── tool/                     # --- Module 3: Bộ Công cụ Nghiệp vụ Đặt xe ---
│   │   ├── api.py                # Factory và registry: `build_voice_taxi_tools`
│   │   ├── map_tool.py           # Công cụ tìm kiếm địa chỉ, tính lộ trình và khoảng cách
│   │   ├── fare_tool.py          # Công cụ tính giá cước theo cự ly và loại phương tiện
│   │   ├── booking_tool.py       # Công cụ tạo đơn tạm (quote), xác nhận và điều phối
│   │   └── _api.py               # HTTP client kết nối các dịch vụ backend
│   │
│   └── speech/                   # --- Module 4: Xử lý Tiếng nói (STT / TTS / WebRTC) ---
│       ├── api.py                # Giao diện tích hợp công khai của module Speech
│       ├── audio_pipeline.py     # LiveKit Audio Pipeline (Azure STT/TTS + Silero VAD)
│       ├── azure_provider.py     # Tích hợp Azure Speech SDK trực tiếp (cho file WAV/Mic)
│       ├── stt_faster_whisper.py # Adapter nhận dạng giọng nói offline Faster-Whisper
│       ├── worker.py             # LiveKit Voice Worker tham gia phòng thoại
│       ├── callback.py           # Quản lý callback xử lý kết quả nhận dạng giọng nói
│       ├── contracts.py          # Kiểu dữ liệu Audio, SpeechEvent, SpeechState
│       ├── metrics.py            # Đo đạc độ trễ và Word Error Rate (WER)
│       ├── config.py             # Cấu hình tham số âm thanh và thông tin xác thực
│       ├── pipeline.py           # Pipeline xử lý âm thanh với callback thay thế được
│       └── adapters/
│           └── core.py           # Kết nối Speech callback với hàm Core API
│
├── services/                     # Tầng Dịch vụ Ngoại vi và Hạ tầng
│   ├── auth.py                   # Xác thực và quản lý token người dùng/phiên làm việc
│   ├── database.py               # Kết nối cơ sở dữ liệu SQLite và lưu trữ đơn đặt xe
│   ├── dispatch.py               # Dịch vụ giả lập / kết nối hệ thống điều phối tài xế
│   ├── endpoints.py              # Cấu hình các URL dịch vụ bên ngoài
│   ├── errors.py                 # Định nghĩa các ngoại lệ chuẩn của hệ thống
│   ├── geocoding.py              # Dịch vụ chuyển đổi địa chỉ thành tọa độ (Geocoding)
│   ├── livekit.py                # Quản lý phòng họp và sinh token truy cập LiveKit
│   ├── routing.py                # Dịch vụ tính toán đường đi và khoảng cách địa lý
│   ├── vietmap.py                # Tích hợp API bản đồ VietMap (tùy chọn)
│   └── voice_store.py            # Lưu trữ và truy xuất các file âm thanh ghi âm
│
├── agents/                       # [Legacy/Compatibility] Wrapper tương thích ngược
│   ├── graph.py, orchestrator.py, state.py, nodes.py
│   └── tools/                    # Các tool wrappers tương thích
│
└── parrotgo/                     # Tài liệu thiết kế MVP, kế hoạch triển khai CLI
```

---

## 3. Các Thư Mục Chức Năng Bổ Trợ

### 3.1. `frontend/` — Giao Diện Người Dùng
- `index.html`: Giao diện gọi điện trực tuyến qua LiveKit (Voice AI call).
- `demo.html`: Giao diện thử nghiệm kết hợp Web Chat + Web Speech API (nhận diện giọng nói trực tiếp qua trình duyệt) với Mock Tools.
- `app.js`: Xử lý logic phía client (WebRTC, WebSocket, Audio visualizer, quản lý mic).
- `style.css`: Giao diện người dùng hiện đại, hỗ trợ hiệu ứng chuyển động và responsive.

### 3.2. `livekit_server/` — Cấu Hình SFU Server
- `livekit.yaml`: Cấu hình máy chủ LiveKit SFU (cổng WebRTC, API key, Secret key, Redis nếu có).

### 3.3. `scripts/` — Bộ Công Cụ và Tự Động Hóa
- `check_audio_pipeline.py`: Kiểm tra kết nối cấu hình của Speech Pipeline.
- `test_speech_e2e.py`: Thử nghiệm end-to-end giọng nói (file WAV hoặc micro trực tiếp qua Azure).
- `benchmark_speech.py`: Đo đạc hiệu năng STT/TTS.
- `voice_demo.py`: Kịch bản thoại thử nghiệm qua giao diện dòng lệnh (CLI).
- `submit_log.py`, `log_manual.py`, `log_hook.py`, `log_antigravity.py`, `log_codex.py`, `ai_log_common.py`: Hệ thống ghi log hoạt động tương tác AI phục vụ báo cáo và giám sát.
- `setup_hooks.ps1` / `setup_hooks.sh`: Cài đặt Git hooks tự động cho repo.

### 3.4. `tests/` — Hệ Thống Kiểm Thử
- `unit/`:
  - `domain/`: Kiểm thử tính toán giá cước, chuẩn hóa địa chỉ, trạng thái booking.
  - `llm/`: Kiểm thử bộ trích xuất thông tin, bộ lập kế hoạch câu thoại, cấu trúc schema.
  - `speech/`: Kiểm thử cấu hình âm thanh, callback và tính toán WER offline.
- `contract/`: Kiểm thử tính tương thích của API công khai, hợp đồng dữ liệu giữa Speech, LLM và Tool.
- `integration/`:
  - `api/`: Kiểm thử các endpoint HTTP (`/api/v1/chat`, `/api/v1/voice-turn`).
  - `core/`: Kiểm thử luồng hội thoại LangGraph, cơ chế khóa xác nhận và chuyển đổi state.
  - `services/`: Kiểm thử dịch vụ Geocoding, LiveKit, Dispatch, Database.
  - `speech/`: Kiểm thử liên kết từ Speech sang Core/LLM/Tool.
  - `tool/`: Kiểm thử bộ 3 công cụ đặt xe với dữ liệu mô phỏng.
- `audio_suite/`: Bộ dữ liệu âm thanh mẫu để benchmark (giọng vùng miền, tạp âm, ngắt lời).

### 3.5. `eval/` — Đánh Giá Hiệu Năng & Độ Chính Xác
- `dev.jsonl`, `holdout.jsonl`: Bộ dữ liệu đánh giá độ chính xác của mô hình ngôn ngữ.
- `tool_call_scenarios.jsonl`: Các kịch bản kiểm tra khả năng gọi công cụ.
- `voice_e2e_16_results.csv`: Kết quả đo đạc 16 kịch bản hội thoại tiếng nói thực tế.
- `results/`: Báo cáo chi tiết các đợt audit chất lượng mã nguồn và độ trễ.

### 3.6. `docs/` — Tài Liệu Hệ Thống
- `MODULE_STRUCTURE.md`: Kiến trúc phân chia chi tiết các module.
- `CORE_LLM_TOOL_INTEGRATION.md`: Hướng dẫn tích hợp giữa Core, LLM và Tool.
- `VOICE_E2E_16_SCENARIOS.md`: 16 kịch bản thử nghiệm đàm thoại giọng nói.
- `STT_TTS_STATUS.md`: Trạng thái và báo cáo chất lượng dịch vụ âm thanh.
- `guide/`: Chuỗi tài liệu hướng dẫn kỹ thuật chuyên sâu từ Chương 1 đến Chương 10 cùng các quy chuẩn hệ thống (Kiến trúc, Style code, DevOps, Testing, Best practices).

### 3.7. `data/` — Lưu Trữ Dữ Liệu
- `rides.db`: Cơ sở dữ liệu SQLite lưu trữ đơn đặt xe, trạng thái chuyến đi và lịch sử hội thoại.

---

## 4. Luồng Dữ Liệu và Tương Tác Giữa Các Thành Phần

```mermaid
flowchart TD
    User([Người dùng]) -->|Giọng nói| Mic[Micro / WebRTC LiveKit]
    User -->|Văn bản| WebDemo[Giao diện Chat / Demo]

    Mic --> STT[STT Module / Azure Speech / Faster-Whisper]
    STT -->|Transcript| CoreAPI[src.modules.core.api: core_func]
    WebDemo -->|Text Turn| CoreAPI

    subgraph Core [LangGraph State Machine]
        ContextNode[Context Node] --> ExtractorNode[Extractor Node]
        ExtractorNode --> ValidationNode[Validation Node]
        ValidationNode --> StateManagerNode[State Manager Node]
        StateManagerNode --> BookingNode[Booking Node]
        BookingNode --> ResponseNode[Response Node]
    end

    CoreAPI --> ContextNode

    ExtractorNode <-->|Structured JSON Schema| LLMExtractor[LLM Extractor]
    ResponseNode <-->|Prompt Generation| LLMPlanner[LLM Planner]

    BookingNode <-->|Tìm địa chỉ & tính cước| TaxiTools[Taxi Tools: Map, Fare, Booking]
    TaxiTools <-->|Query & Persist| Services[Services: Geocoding, Pricing, DB]

    ResponseNode -->|Phản hồi văn bản| CoreAPI
    CoreAPI -->|Văn bản| WebDemo
    CoreAPI -->|Văn bản| TTS[TTS Module / Azure Speech]
    TTS -->|Âm thanh tổng hợp| Spk([Loa / WebRTC Audio])
```

---

## 5. Bảng Tổng Hợp Điểm Khởi Chạy (Entrypoints)

| Chế độ thực thi | Điểm vào (Entrypoint) | Mô tả vai trò |
| :--- | :--- | :--- |
| **Backend & Web Server** | `src/main.py` | Chạy máy chủ FastAPI quản lý API chat, voice-turn và phục vụ frontend tĩnh. |
| **LiveKit Voice Worker** | `worker/agent.py` | Lắng nghe luồng audio từ phòng LiveKit, thực thi STT $\to$ Core $\to$ TTS trực tiếp. |
| **Web Demo (Voice & Text)** | `http://localhost:8000/demo.html` | Thử nghiệm đặt xe qua trình duyệt với Web Speech API hoặc gửi tin nhắn văn bản. |
| **LiveKit Call Web UI** | `http://localhost:8000/` | Giao diện cuộc gọi thoại hai chiều độ trễ thấp qua WebRTC. |
| **CLI Quick MVP** | `run_mvp.py` | Chạy nhanh kịch bản đặt xe tương tác qua dòng lệnh. |
| **Kiểm thử âm thanh độc lập** | `scripts/test_speech_e2e.py` | Kiểm tra STT/TTS độc lập với file âm thanh WAV hoặc micro máy tính. |
| **Chạy kiểm thử tự động** | `pytest tests/` | Chạy toàn bộ bộ test kiểm tra Unit, Contract và Integration. |
