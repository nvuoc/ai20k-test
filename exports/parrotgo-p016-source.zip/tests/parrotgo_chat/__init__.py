"""Portable chat regression tests."""
